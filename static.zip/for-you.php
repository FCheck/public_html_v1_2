
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(/images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    FraudCheck For You
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
    
    <div class="container">
    
    	<div class="row">
        	<div class="col-lg-7">
            	<div class="page-header green-heading">
                    <a name="getownscore"></a>
                  <strong>Get My Own Credit Score</strong>
                </div>
                    The FraudCheck portal allows individuals to check their own credit rating. This may be important when an individual is applying for credit or new employment. 
        <br /><br />
        It is far better for you to be forearmed prior to such an event. This will allow you to be able to query any default or incorrect credit history that may be recorded on your profile and deal with it prior to applying for credit or new employment. 
        
				<div class="space"></div>
                <div class="page-header green-heading">
                    <a name="check"></a>
                    <strong>Check Someone</strong>
                </div>
                Prior to checking an independent persons credit history you legally will require permission from that individual. Companies, recruitment agents and finance companies would generally have written permission from the applicant to allow them to perform such checks. 
        <br /><br />
        FraudCheck have implemented a SMS confirmation system to assist with 3rd party confirmations. 
        <br /><br />
        A one-time pin will be sent to the person being checked by way of SMS requesting permission for the credit check to be conducted. Once the person being checked provides permission by responding to the SMS, the credit check will immediately be processed and available for viewing.
        <br>
<br>
<br>
<br>
            </div>
            <div class="col-lg-5">
       	    <img src="/images/img/content_image2.jpg" width="448" height="478" alt=""/> </div>
        </div>
    </div>
    
    
    
    
    
   <a href="#0" class="cd-top">Top</a>
