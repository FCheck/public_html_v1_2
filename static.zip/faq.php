	
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    Frequently Asked Questions
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
    
    
    
    <div class="container">
      
    	
        <div class="table-responsive">
    	<div class="desktop">
        <div class="row space">
            <div class="col-md-12 text-center">
            <ul class="faq-menu">
				<li><a class="scroll" href="#name">General</a></li>
				<li>&nbsp;|&nbsp;</li>
				<li><a class="scroll" href="#data">Data Protection</a></li>
				<li>&nbsp;|&nbsp;</li>
				<li><a class="scroll" href="#email">Emails &amp; SMSs</a></li>
				<li>&nbsp;|&nbsp;</li>
				<li><a class="scroll" href="#fees">Fees &amp; Payments</a></li>
				<li>&nbsp;|&nbsp;</li>
				<li><a class="scroll" href="#support">Support</a></li>
				<li>&nbsp;|&nbsp;</li>
				<li><a class="scroll" href="#business">Business</a></li>
			</ul>
          </div>
       </div>
        <table class="faq">
			<thead>
				<tr class="head">
					<th>Question</th>
					<th>Answer</th>
					<th>Category</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td class="q"><a id="general"></a>Are FraudCheck services
						available for my country?</td>
					<td>FraudCheck is available to South African citizens
							and all foreign nationals that live in South Africa permanently
							with a valid RSA Identity Document.
						We are looking into using Passport Numbers for fraud screening &amp; ID verification in the near 
							future - watch this space.</td>
					<td class="category">General</td>
				</tr>
				<tr>
					<td class="q">How quickly will I get a result for my
						FraudCheck?</td>
					<td>You will get the result of your Person Check in real time, on the website, immediately after 
							submitting the Person's details and selecting a fraud screening product.
						
							<span style="font-style: underline">Please note</span> that completing the person check 
							could take up to 30 seconds, so please be patient while FraudCheck completes the check and 
							compiles the fraud screening recommendation.
						</td>
					<td class="category">General</td>
				</tr>
				<tr>
					<td class="q">What are the Terms and Conditions?</td>
					<td>The FraudCheck Terms and Conditions can be found <a href="/ts-and-cs">here</a>.
					</td>
					<td class="category">General</td>
				</tr>
				<tr>
					<td class="q">Which data does FraudCheck use when performing a
						check?</td>
					<td>When you request an ID Check, the details that you
							provide are compared to Home Affairs data and to a limited amount
							of credit bureau data.
						When you request a Full Person Check, the details that you
							provide are compared to Home Affairs and extensive credit bureau
							data.
						<br>
							<strong>NOTE</strong> that the credit bureau data is based on the
							information that you provide when applying for credit at most
							service providers in South Africa. As such, the credit bureau
							data is only as accurate as the information that you provide at
							service providers, and it is only as up to date as your latest
							credit application.
						</td>
					<td class="category">General</td>
				</tr>
				<tr>
					<td class="q">Which check is best suited for you?</td>
					<td>The credit bureau data that is used during a Full
							Person Check is largely dependent on the information that was
							obtained from a person during a credit application. If the person
							is younger than 18, no credit application data will exist.
						As such, if you want to check a person that is younger than 18, FraudCheck would recommend 
							using the Basic ID Check product. For any person older than 18, you may get the best result 
							when completing a Full Person Check.</td>
					<td class="category">General</td>
				</tr>
				<tr>
					<td class="q">Which data partners does FraudCheck use?</td>
					<td>FraudCheck's current data partners are: <br>
						TransUnion, XDS &amp; AfriGIS
					</td>
					<td class="category">General</td>
				</tr>
				<tr>
					<td class="q">What is the dispute procedure?</td>
					<td>If you disagree with the recommendation that you received for a person verification check, you 
						are able to dispute the result at any time. Raising a dispute is as simple as registering as a 
						FraudCheck user and then clicking a Dispute button for the person check when you disagree with 
						the fraud screening recommendation that FraudCheck made. When you click the Dispute button, a 
						dispute ticket is logged at FraudCheck and we will investigate and respond within 2 business 
						days from the time that you send it.</td>
					<td class="category">General</td>
				</tr>

				<tr>
					<td class="q">Does my activation/confirmation code expire?</td>
					<td>No. The unique code that we send to you will remain valid
						until you have used it. Note that you will not be able to use the
						same activation or confirmation code more than once.</td>
					<td class="category">General</td>
				</tr>

				<tr>
					<td class="q">What am I paying for?</td>
					<td>
						When you choose to perform a FraudCheck person verification check, we first collect data 
							records from our partners for the person that you want to check, then we evaluate and 
							interpret the data records that we received, using an exhaustive set of real-time rules and 
							lastly, we produce an easy to understand fraud screening recommendation report of our 
							findings. We also check a person against data that is held by FraudCheck to ensure that we 
							use ALL the information that is available to us when we produce the result of your 
							FraudCheck person verification check.
						It is important to note that we WILL NOT share the actual data records that we received from 
							our partners - we will only share our interpretation of the data records, making it easy for 
							you to understand and make a decision! In a nutshell, our interpretation of the complex data 
							records and the report that we produce is what you are paying for.
					</td>
					<td class="category">General</td>
				</tr>
				<tr>
					<td class="q">Does a FraudCheck affect my credit score?</td>
					<td>
						It may affect your credit score if many people check you
							during a specific period of time. The Credit Bureaux only view
							the enquiries that are done for your Id Number as a bad thing
							when many enquiries take place within a short period of time.
					</td>
					<td class="category">General</td>
				</tr>

				<tr>
					<td class="q">When I perform a check on the same person, will FraudCheck notify me that I have already 
						performed a check on that person?</td>
					<td>
						FraudCheck will identify a duplicate check (by using the ID Number provided) during a 
							configured time window. You can request a specific time window configuration for duplicate 
							checks on your account by sending an email to <a href="mailto:support@fraudcheck.co.za">
								support@fraudcheck.co.za</a>. The email must contain the number of days (between 1 and 
							30) that you wish to return the previous check results as apposed to re-screening the same person.
					</td>
					<td class="category">General</td>
				</tr>				

				<tr>
					<td class="q">If I perform a check on the same person, will FraudCheck charge me for each check?</td>
					<td>
						FraudCheck will not charge you for a duplicate check within your configured time window. 
							Please note that if this window is set too large, there is no override facility as yet to 
							force a new check. The new check is only performed once outside the window. We therefore 
							suggest keeping the window to 1 or 2 days.
					</td>
					<td class="category">General</td>
				</tr>					

				<tr>
					<td class="q"><a id="data"></a>Who will be able to access my
						account information?</td>
					<td>Your account information is stored securely on
						FraudCheck's server and it will only be accessible to the
						FraudCheck staff that performs data maintenance tasks. The
						information will <b>not</b> be available publically or shared
						without permission pursuant to our <a href="/ts-and-cs">Terms &amp; Conditions</a>.
					</td>
					<td class="category">Data Protection</td>
				</tr>
				<tr>
					<td class="q">When I send my ID number is it visible to the
						person checking me?</td>
					<td>No. When you give permission for a person to check you,
						your ID Number is stored in the FraudCheck system. The full number
						is never displayed to the person that wants to check you.</td>
					<td class="category">Data Protection</td>
				</tr>
				<tr>
					<td class="q">Will the person checking me see my credit bureau
						(TransUnion) report?</td>
					<td>No. FraudCheck evaluates the information that we receive
						from the different credit bureaux and makes a recommendation based
						on the interpretation of your data. The information from the
						credit bureau is never displayed to the person that checks you.</td>
					<td class="category">Data Protection</td>
				</tr>
				<tr>
					<td class="q">Will the person checking me have access to my
						personal data?</td>
					<td>No. The person that checks you will only have access to
						the information that you provided to them prior to the check. They
						won't even be able to see your whole ID number as we mask this.
						The personal information that we receive from the different credit
						bureaux and providers is never displayed to the person that checks
						you.</td>
					<td class="category">Data Protection</td>
				</tr>

				<tr>
					<td class="q"><a id="email"></a>Why am I not receiving my
						request for permission SMS?</td>
					<td>
							You will not receive an SMS if you have previously sent an SMS
							containing <q>CONSENT</q> plus any of the following words to
							31771:<br> STOP, END, CANCEL, UNSUBSCRIBE, QUIT, STOP STOP or
							STOP ALL
						
						
							To receive SMS's from FraudCheck again, please send an SMS
							containing only the word <q>CONSENT</q> to 31771.
						
						
							If your issue persists, please do not hesitate to contact
							FraudCheck Support on <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>.
						</td>
					<td class="category">Emails &amp; SMSs</td>
				</tr>
				<tr>
					<td class="q">How do I stop getting requests from FraudCheck?</td>
					<td>
							You can block all SMS's from FraudCheck if you send <q>CONSENT</q>
							plus any of the following words to 31771:<br> STOP, END,
							CANCEL, UNSUBSCRIBE, QUIT, STOP STOP or STOP ALL
						
						
							If your issue persists, please do not hesitate to contact
							FraudCheck Support on <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>.
						</td>
					<td class="category">Emails &amp; SMSs</td>
				</tr>
				<tr>
					<td class="q">Can I give consent to be checked via email if my
						consent SMS fails?</td>
					<td>
							Yes, you can! If the consent SMS that you sent fails for some
							reason and the person that want to check you cannot see that you
							provided consent, you can email your consent to <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>.
							PLEASE NOTE that you will need to register as a FraudCheck user
							first (registration is FREE). Then, following registration, you
							can send your consent email from the email address that you used
							when you registered. When sending your consent email, please
							include only CONSENT, the 3-digit code that appeared in the
							consent request SMS, plus your ID Number, e.g. CONSENT 123
							7501011234080.
						</td>
					<td class="category">Emails &amp; SMSs</td>
				</tr>
				<tr>
					<td class="q">Why do I keep getting a response “The ID number that you have sent is invalid...” 
						when entering the correct ID number?</td>
					<td>
							Please ensure that the format of your SMS is correct: CONSENT (space) CODE (space) ID NUMBER, 
							e.g. CONSENT 123 7501011234080.<br>
							If your issue persists, please do not hesitate to contact FraudCheck Support on 
							<a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>.
						</td>
					<td class="category">Emails &amp; SMSs</td>
				</tr>				

				<tr>
					<td class="q"><a id="fees"></a>How much does FraudCheck
						registration cost?</td>
					<td>Registration for FraudCheck is free. Charges will only be
						incurred when you buy tokens to check a Person.</td>
					<td class="category">Fees &amp; Payments</td>
				</tr>
				<tr>

					<td class="q">How much does a Person Check cost?</td>
					<td>The cost of a Person Check varies, depending on the type
						of check that you want. Please see the cost per type of check on
						the FraudCheck Home page.</td>
					<td class="category">Fees &amp; Payments</td>
				</tr>
				<tr>
					<td class="q">How do I pay for a FraudCheck?</td>
					<td>Each FraudCheck costs a set number of credits.
							Credits can be purchased using your credit card or non-pin debit
							card when you are logged into your FraudCheck account.

						Our payment service provider, Virtual Card Services, will
							capture your payment details on their secure purchase page. If
							your bank supports Verified by Visa or MasterCard SecureCode, you
							may be redirected to your bank's pin verification page.</td>
					<td class="category">Fees &amp; Payments</td>
				</tr>
				<tr>
					<td class="q">Can I get a refund for my unused credits?</td>
					<td>No, unfortunately not. If you expect to use FraudCheck
						regularly, you can purchase multiple credits at a time. If you DO
						NOT expect to use FraudCheck regularly, we recommend that you
						purchase only enough for the checks that you want to complete.</td>
					<td class="category">Fees &amp; Payments</td>
				</tr>
				<tr>
					<td class="q">Can I purchase FraudCheck credits without using
						my credit/debit card?</td>
					<td>Yes, you can! If you wish to purchase credits without
						using your credit/debit card, you can send a purchase request to <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>.
						PLEASE NOTE that the email must be from the email address that you
						used when you registered as a FraudCheck user! Our Support team
						will respond to your request with our bank account details and a
						unique reference number that you must include in your payment.
						When you have completed your manual payment (either via online
						banking or by visiting your bank), you will need to respond to the
						Support request with your proof of payment. Lastly, we will credit
						your account with the number of credits that you paid for.
					</td>
					<td class="category">Fees &amp; Payments</td>
				</tr>

				<tr>
					<td class="q"><a id="business"></a>Can a business register for
						FraudCheck services (as opposed to an individual)?</td>
					<td>Yes. Please contact FraudCheck Support on <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>
						to find out more.
					</td>
					<td class="category">Business</td>
				</tr>

				<tr>
					<td class="q"><a id="support"></a>How quickly will I get a
						response when I email FraudCheck Support?</td>
					<td>All queries that are sent to FraudCheck Support will
						receive feedback within 1 business day from the time that you send
						it.</td>
					<td class="category">Support</td>
				</tr>
				<tr class="last">
					<td class="q">How do I log a query or support call with
						FraudCheck?</td>
					<td>All you need to do is drop us an email to <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>. 
						Please be sure to send us the email from your registered email
						account with us so that we know who you are.
					</td>
					<td class="category">Support</td>
				</tr>
			</tbody>
		</table>
    	</div>
    </div>
    </div>
    
     <!-- start mobile survey -->
       <div class="mobile">
            	<div class="container">
					<div class="row space">
            <div class="col-md-12 text-center">
            <ul class="faq-menu">
				<li><a class="scroll" href="#name_mobile">General</a></li>
				<li>&nbsp;|&nbsp;</li>
				<li><a class="scroll" href="#data_mobile">Data Protection</a></li>
				<li>&nbsp;|&nbsp;</li>
				<li><a class="scroll" href="#email_mobile">Emails &amp; SMSs</a></li>
				<li>&nbsp;|&nbsp;</li>
				<li><a class="scroll" href="#fees_mobile">Fees &amp; Payments</a></li>
				<li>&nbsp;|&nbsp;</li>
				<li><a class="scroll" href="#support_mobile">Support</a></li>
				<li>&nbsp;|&nbsp;</li>
				<li><a class="scroll" href="#business_mobile">Business</a></li>
			</ul>
          </div>
       </div>
						<div class="col-md-4 mobile column">
                        <a id="name_mobile"></a><p><span class="sub_heading">Question :</span> Are FraudCheck services available for my country?</p>
                        <p><span class="sub_heading">Answer :</span> FraudCheck is available to South African citizens and all foreign nationals that live in South Africa permanently with a valid RSA Identity Document. We are looking into using Passport Numbers for fraud screening & ID verification in the near future - watch this space.</p>
                        <p><span class="sub_heading">Category :</span> General</p>
                        </div>
                        <div class="line5"></div>
                        
                        <div class="col-md-4 mobile column">
                        <p><span class="sub_heading">Question :</span> How quickly will I get a result for my FraudCheck?</p>
                        <p><span class="sub_heading">Answer :</span> You will get the result of your Person Check in real time, on the website, immediately after submitting the Person's details and selecting a fraud screening product. Please note that completing the person check could take up to 30 seconds, so please be patient while FraudCheck completes the check and compiles the fraud screening recommendation.</p>
                        <p><span class="sub_heading">Category :</span> General</p>
                        </div>
                        <div class="line5"></div>
                        
                         <div class="col-md-4 mobile column">
                        <p><span class="sub_heading">Question :</span> What are the Terms and Conditions?</p>
                        <p><span class="sub_heading">Answer :</span> The FraudCheck Terms and Conditions can be found <a href="/ts-and-cs">here</a></p>
                        <p><span class="sub_heading">Category :</span> General</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                         <div class="col-md-4 mobile column">
                        <p><span class="sub_heading">Question :</span> Which data does FraudCheck use when performing a check?</p>
                        <p><span class="sub_heading">Answer :</span> When you request an ID Check, the details that you provide are compared to Home Affairs data and to a limited amount of credit bureau data. When you request a Full Person Check, the details that you provide are compared to Home Affairs and extensive credit bureau data. <br><strong>NOTE</strong> that the credit bureau data is based on the information that you provide when applying for credit at most service providers in South Africa. As such, the credit bureau data is only as accurate as the information that you provide at service providers, and it is only as up to date as your latest credit application.</p>
                        <p><span class="sub_heading">Category :</span> General</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                         <div class="col-md-4 mobile column">
                        <p><span class="sub_heading">Question :</span> Which check is best suited for you?</p>
                        <p><span class="sub_heading">Answer :</span> The credit bureau data that is used during a Full Person Check is largely dependent on the information that was obtained from a person during a credit application. If the person is younger than 18, no credit application data will exist. As such, if you want to check a person that is younger than 18, FraudCheck would recommend using the Basic ID Check product. For any person older than 18, you may get the best result when completing a Full Person Check.</p>
                        <p><span class="sub_heading">Category :</span> General</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                        <div class="col-md-4 mobile column">
                        <p><span class="sub_heading">Question :</span> Which data partners does FraudCheck use?</p>
                        <p><span class="sub_heading">Answer :</span> FraudCheck's current data partners are: <br>
TransUnion, XDS & AfriGIS</p>
                        <p><span class="sub_heading">Category :</span> General</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                         <div class="col-md-4 mobile column">
                        <p><span class="sub_heading">Question :</span> What is the dispute procedure?</p>
                        <p><span class="sub_heading">Answer :</span> If you disagree with the recommendation that you received for a person verification check, you are able to dispute the result at any time. Raising a dispute is as simple as registering as a FraudCheck user and then clicking a Dispute button for the person check when you disagree with the fraud screening recommendation that FraudCheck made. When you click the Dispute button, a dispute ticket is logged at FraudCheck and we will investigate and respond within 2 business days from the time that you send it.</p>
                        <p><span class="sub_heading">Category :</span> General</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                        <div class="col-md-4 mobile column">
                        <span class="sub_heading">Question :</span> <p>Does my activation/confirmation code expire?</p>
                        <p><span class="sub_heading">Answer :</span> No. The unique code that we send to you will remain valid until you have used it. Note that you will not be able to use the same activation or confirmation code more than once.</p>
                        <p><span class="sub_heading">Category :</span> General</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                         <div class="col-md-4 mobile column">
                        <span class="sub_heading">Question :</span> <p>What am I paying for?</p>
                        <p><span class="sub_heading">Answer :</span>When you choose to perform a FraudCheck person verification check, we first collect data records from our partners for the person that you want to check, then we evaluate and interpret the data records that we received, using an exhaustive set of real-time rules and lastly, we produce an easy to understand fraud screening recommendation report of our findings. We also check a person against data that is held by FraudCheck to ensure that we use ALL the information that is available to us when we produce the result of your FraudCheck person verification check. It is important to note that we WILL NOT share the actual data records that we received from our partners - we will only share our interpretation of the data records, making it easy for you to understand and make a decision! In a nutshell, our interpretation of the complex data records and the report that we produce is what you are paying for.</p>
                        <p><span class="sub_heading">Category :</span> General</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                        <div class="col-md-4 mobile column">
                        <span class="sub_heading">Question :</span> <p>Does a FraudCheck affect my credit score?</p>
                        <p><span class="sub_heading">Answer :</span>It may affect your credit score if many people check you during a specific period of time. The Credit Bureaux only view the enquiries that are done for your Id Number as a bad thing when many enquiries take place within a short period of time.</p>
                        <p><span class="sub_heading">Category :</span> General</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                        
                        <div class="col-md-4 mobile column">
                        <span class="sub_heading">Question :</span> <p>When I perform a check on the same person, will FraudCheck notify me that I have already performed a check on that person?</p>
                        <p><span class="sub_heading">Answer :</span>FraudCheck will identify a duplicate check (by using the ID Number provided) during a configured time window. You can request a specific time window configuration for duplicate checks on your account by sending an email to <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>. The email must contain the number of days (between 1 and 30) that you wish to return the previous check results as apposed to re-screening the same person.</p>
                        <p><span class="sub_heading">Category :</span> General</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                         <div class="col-md-4 mobile column">
                        <span class="sub_heading">Question :</span> <p>If I perform a check on the same person, will FraudCheck charge me for each check?</p>
                        <p><span class="sub_heading">Answer :</span>FraudCheck will not charge you for a duplicate check within your configured time window. Please note that if this window is set too large, there is no override facility as yet to force a new check. The new check is only performed once outside the window. We therefore suggest keeping the window to 1 or 2 days.</p>
                        <p><span class="sub_heading">Category :</span> General</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                        
                        <div class="col-md-4 mobile column">
                        <a id="data_mobile"></a><span class="sub_heading">Question :</span> <p>Who will be able to access my account information?</p>
                        <p><span class="sub_heading">Answer :</span>Your account information is stored securely on FraudCheck's server and it will only be accessible to the FraudCheck staff that performs data maintenance tasks. The information will not be available publically or shared without permission pursuant to our <a href="/ts-and-cs">Terms &amp; Conditions</a>.</p>
                        <p><span class="sub_heading">Category :</span> Data Protection</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                        <div class="col-md-4 mobile column">
                        <a id="data_mobile"></a><span class="sub_heading">Question :</span> <p>When I send my ID number is it visible to the person checking me?</p>
                        <p><span class="sub_heading">Answer :</span>No. When you give permission for a person to check you, your ID Number is stored in the FraudCheck system. The full number is never displayed to the person that wants to check you.</p>
                        <p><span class="sub_heading">Category :</span> Data Protection</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                         <div class="col-md-4 mobile column">
                        <a id="data_mobile"></a><span class="sub_heading">Question :</span> <p>Will the person checking me see my credit bureau (TransUnion) report?</p>
                        <p><span class="sub_heading">Answer :</span>No. FraudCheck evaluates the information that we receive from the different credit bureaux and makes a recommendation based on the interpretation of your data. The information from the credit bureau is never displayed to the person that checks you.</p>
                        <p><span class="sub_heading">Category :</span> Data Protection</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                         <div class="col-md-4 mobile column">
                        <a id="data_mobile"></a><span class="sub_heading">Question :</span> <p>Will the person checking me have access to my personal data?</p>
                        <p><span class="sub_heading">Answer :</span>No. The person that checks you will only have access to the information that you provided to them prior to the check. They won't even be able to see your whole ID number as we mask this. The personal information that we receive from the different credit bureaux and providers is never displayed to the person that checks you.</p>
                        <p><span class="sub_heading">Category :</span> Data Protection</p>
                        </div>
                        
                        <div class="line5"></div>
                      

                         <div class="col-md-4 mobile column">
                        <a id="email_mobile"></a><span class="sub_heading">Question :</span> <p>Why am I not receiving my request for permission SMS?</p>
                        <p><span class="sub_heading">Answer :</span>You will not receive an SMS if you have previously sent an SMS
							containing <q>CONSENT</q> plus any of the following words to
							31771:<br> STOP, END, CANCEL, UNSUBSCRIBE, QUIT, STOP STOP or
							STOP ALL
						
						
							To receive SMS's from FraudCheck again, please send an SMS
							containing only the word <q>CONSENT</q> to 31771.
						
						
							If your issue persists, please do not hesitate to contact
							FraudCheck Support on <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>.</p>
                        <p><span class="sub_heading">Category :</span> Emails &amp; SMSs</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                        <div class="col-md-4 mobile column">
                        <a id="email_mobile"></a><span class="sub_heading">Question :</span> <p>How do I stop getting requests from FraudCheck?</p>
                        <p><span class="sub_heading">Answer :</span>You can block all SMS's from FraudCheck if you send <q>CONSENT</q>
							plus any of the following words to 31771:<br> STOP, END,
							CANCEL, UNSUBSCRIBE, QUIT, STOP STOP or STOP ALL
						
						
							If your issue persists, please do not hesitate to contact
							FraudCheck Support on <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>.
</p>
                        <p><span class="sub_heading">Category :</span> Emails &amp; SMSs</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                         <div class="col-md-4 mobile column">
                        <a id="email_mobile"></a><span class="sub_heading">Question :</span> <p>Can I give consent to be checked via email if my
						consent SMS fails?</p>
                        <p><span class="sub_heading">Answer :</span>Yes, you can! If the consent SMS that you sent fails for some
							reason and the person that want to check you cannot see that you
							provided consent, you can email your consent to <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>.
							PLEASE NOTE that you will need to register as a FraudCheck user
							first (registration is FREE). Then, following registration, you
							can send your consent email from the email address that you used
							when you registered. When sending your consent email, please
							include only CONSENT, the 3-digit code that appeared in the
							consent request SMS, plus your ID Number, e.g. CONSENT 123
							7501011234080.

</p>
                        <p><span class="sub_heading">Category :</span> Emails &amp; SMSs</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                         <div class="col-md-4 mobile column">
                        <a id="email_mobile"></a><span class="sub_heading">Question :</span> <p>Why do I keep getting a response “The ID number that you have sent is invalid...” 
						when entering the correct ID number?</p>
                        <p><span class="sub_heading">Answer :</span>Please ensure that the format of your SMS is correct: CONSENT (space) CODE (space) ID NUMBER, 
							e.g. CONSENT 123 7501011234080.<br>
							If your issue persists, please do not hesitate to contact FraudCheck Support on 
							<a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>.


</p>
                        <p><span class="sub_heading">Category :</span> Emails &amp; SMSs</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                        
                        <div class="col-md-4 mobile column">
                        <a id="fees_mobile"></a><span class="sub_heading">Question :</span> <p>How much does FraudCheck
						registration cost?</p>
                        <p><span class="sub_heading">Answer :</span>Registration for FraudCheck is free. Charges will only be incurred when you buy tokens to check a Person.


</p>
                        <p><span class="sub_heading">Category :</span> Fees &amp; Payments</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                        <div class="col-md-4 mobile column">
                        <a id="fees_mobile"></a><span class="sub_heading">Question :</span> <p>How much does a Person Check cost?</p>
                        <p><span class="sub_heading">Answer :</span>The cost of a Person Check varies, depending on the type
						of check that you want. Please see the cost per type of check on
						the FraudCheck Home page.


</p>
                        <p><span class="sub_heading">Category :</span> Fees &amp; Payments</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                        <div class="col-md-4 mobile column">
                        <a id="fees_mobile"></a><span class="sub_heading">Question :</span> <p>How do I pay for a FraudCheck?</p>
                        <p><span class="sub_heading">Answer :</span>Each FraudCheck costs a set number of credits.
							Credits can be purchased using your credit card or non-pin debit
							card when you are logged into your FraudCheck account.

						Our payment service provider, Virtual Card Services, will
							capture your payment details on their secure purchase page. If
							your bank supports Verified by Visa or MasterCard SecureCode, you
							may be redirected to your bank's pin verification page.


</p>
                        <p><span class="sub_heading">Category :</span> Fees &amp; Payments</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                        
                         <div class="col-md-4 mobile column">
                        <a id="fees_mobile"></a><span class="sub_heading">Question :</span> <p>Can I get a refund for my unused credits?</p>
                        <p><span class="sub_heading">Answer :</span>No, unfortunately not. If you expect to use FraudCheck
						regularly, you can purchase multiple credits at a time. If you DO
						NOT expect to use FraudCheck regularly, we recommend that you
						purchase only enough for the checks that you want to complete.


</p>
                        <p><span class="sub_heading">Category :</span> Fees &amp; Payments</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                        <div class="col-md-4 mobile column">
                        <a id="fees_mobile"></a><span class="sub_heading">Question :</span> <p>Can I purchase FraudCheck credits without using
						my credit/debit card?</p>
                        <p><span class="sub_heading">Answer :</span>Yes, you can! If you wish to purchase credits without
						using your credit/debit card, you can send a purchase request to <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>.
						PLEASE NOTE that the email must be from the email address that you
						used when you registered as a FraudCheck user! Our Support team
						will respond to your request with our bank account details and a
						unique reference number that you must include in your payment.
						When you have completed your manual payment (either via online
						banking or by visiting your bank), you will need to respond to the
						Support request with your proof of payment. Lastly, we will credit
						your account with the number of credits that you paid for.


</p>
                        <p><span class="sub_heading">Category :</span> Fees &amp; Payments</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                       
                        
                        
                         <div class="col-md-4 mobile column">
                        <a id="business_mobile"></a><span class="sub_heading">Question :</span> <p>Can a business register for
						FraudCheck services (as opposed to an individual)?</p>
                        <p><span class="sub_heading">Answer :</span>Yes. Please contact FraudCheck Support on <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>
						to find out more.


</p>
                        <p><span class="sub_heading">Category :</span> Business</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                        <div class="col-md-4 mobile column">
                        <a id="support_mobile"></a><span class="sub_heading">Question :</span> <p>How quickly will I get a
						response when I email FraudCheck Support?</p>
                        <p><span class="sub_heading">Answer :</span>All queries that are sent to FraudCheck Support will
						receive feedback within 1 business day from the time that you send
						it.


</p>
                        <p><span class="sub_heading">Category :</span> Support</p>
                        </div>
                        
                        <div class="line5"></div>
                        
                         <div class="col-md-4 mobile column">
                        <a id="support_mobile"></a><span class="sub_heading">Question :</span> <p>How do I log a query or support call with
						FraudCheck?</p>
                        <p><span class="sub_heading">Answer :</span>All you need to do is drop us an email to <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>. 
						Please be sure to send us the email from your registered email
						account with us so that we know who you are.



</p>
                        <p><span class="sub_heading">Category :</span> Support</p>
                        </div>
                    </div>
                
       </div>
                        
                       
	<div class="space"></div>
    
    
   <a href="#0" class="cd-top">Top</a>