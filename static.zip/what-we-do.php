
<!-- Header Image
    ================================================== -->
<div class="jumbotron subheadbanner">
  <div class="container content-header">
    <h1>About Us</h1>
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
    
    <div class="container space">
    	<div class="row">
            <div class="col-md-12">
            	<h2 class="green-heading">About Fraudcheck</h2>
            	<p><span class="service-question">The Bad News: Identity fraud is real and rife!</span><br />
				<span class="service-answer">Thousands of individuals, consumers and businesses are defrauded each year by individuals claiming to be something or someone who they are not, in all kinds of transactions.</span></p>
                <p><span class="service-question">The Good News: Identity fraud is preventable!</span><br />
                <span class="service-answer">With the right information at the right time, many of the devastating losses experienced by victims of fraud are preventable. </span></p>
                <p>FraudCheck is in the business of protecting its users against fraud by providing the information needed, educating them about ways to identify fraud and creating a greater awareness of the many types of and ways in which identity fraud is perpetrated.</p>
                <h3 class="green-heading">Because you have more important things to be doing… </h3>
                <p>We are not only passionate about preventing the risks and costs associated with fraud by giving you accurate and timeous information, we also believe in removing the anxiety of decision making so that you can get on with living your life or running your business; doing what you are good at with peace of mind. </p>
                <h3 class="green-heading">What makes FraudCheck different from the rest?</h3>
                <ul>
                	<li><strong>“All Aboard!”</strong> Unlike other background screening companies, our focus is on identity fraud prevention for a broad base of clients. Whether you are an individual who uses online dating, employs domestic workers in your home, who lets the ‘granny flat’ out to tenants or is applying for credit for your dream purchase OR a business or enterprise granting credit, managing property leases, employing staff or engaging in labour broking we have a solution for you.</li>
                
                	<li><strong>“Ain’t NOBODY got time for that!”</strong> Because we understand that opportunities will be missed if critical decisions are not made quickly, our system offers real-time results delivered to you online. The comprehensive information contained in our unique 360 degree scorecard, which is based on YOUR business rules, empowers strong decision making, eliminates hours of sifting through verification reports and removes all anxiety and second guessing when making important decisions.</li>
                
                	<li><strong>“Knowledge is Power!”</strong> While we consider ourselves experts in identifying fraudulent behaviour, fraudsters continue to find new and more devious ways to cheat the system. Through our online Knowledge Centre we continually raise awareness of the various ways in which identity fraud is committed. We also offer onsite training in the use of our products, in particular the taking of finger-prints required for Criminal Checks. Educating our clients is simply another way that we protect them; forewarned is forearmed!</li>
                </ul>
                <h3 class="green-heading">How does the FraudCheck platform work?</h3>
                <p>FraudCheck screens the personal information that you provide against data obtained from our Verification Partners for that particular person. Fraudcheck products range from Basic ID verification to Full Person background screening (credit checks), and provide a real-time fraud screening recommendation result that is clear, concise and easy to understand. 
                FraudCheck is also a licensed supplier of AFISwitch Criminal Record Checks which enables its clients to easily and quickly capture fingerprints either remotely or at our premises prior to conducting a Criminal Check. Fingerprints are processed within 4 – 24 hours.</p>
                
                <h3 class="green-heading">How much does it cost?</h3>
                <p>Our unique menu pricing structure makes our service affordable and easy to access for individuals and organisations. We offer bundle pricing for regular users and large enterprises that require multiple checks, whilst the individual or ad hoc user can purchase credits as needed. <a href="purchase-credits">Click here</a> for our pricing structure.</p>
				<a href="register"><input type="button" class="btn btn-primary" value="CLICK HERE TO GET STARTED" /></a>
            </div>
        </div>
    </div>

	<div class="space"></div>
	
   <a href="#0" class="cd-top">Top</a>
