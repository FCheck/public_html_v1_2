
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    Pricing
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
<div class="container">
<div class="page-header">
    	<h2 class="green-heading"><strong>Pre-paid Credit Purchase</strong></h2>    
    </div>
<div class="container space">
    	<div class="row">
            <div class="col-md-7">
            The FraudCheck portal has been developed using the pre-paid credit system for your convenience. 
<br /><br />
Simply login or <a href="register">register</a> to click on the purchase credits tab and you will be directed to a fully secure 3rd party payment gateway allowing you to purchase the number of credits that you may require. Remaining credits may be used at anytime in the future.
<br /><br />
<strong style="font-size:16px">1 Credit = R10,00 ex VAT</strong>
<div class="space"></div>
<?php 
	$credits = new Credits (); 
?>
<table>
	<tr>
        <td width="200" style="padding:4px"><a href="services/id-check">ID Check</a></td>
        <td style="padding:4px"><?php echo $credits->credits_with_text ('id'); ?></td>
    </tr>
    <tr>
        <td style="padding:4px"><a href="services/credit-check">Credit Check</a></td>
        <td style="padding:4px"><?php echo $credits->credits_with_text ('credit'); ?></td>
    </tr>
    <tr>
        <td style="padding:4px"><a href="services/criminal-check">Criminal Check</a></td>
        <td style="padding:4px"><?php echo $credits->credits_with_text ('criminal'); ?></td>
    </tr>
    <tr>
        <td style="padding:4px"><a href="services/drivers-license-check">Drivers License Check</a></td>
        <td style="padding:4px"><?php echo $credits->credits_with_text ('drivers'); ?></td>
    </tr>
    <tr>
        <td style="padding:4px"><a href="services/matric-verification">Matric Check</a></td>
        <td style="padding:4px"><?php echo $credits->credits_with_text ('matric'); ?></td>
    </tr>
    <tr>
        <td style="padding:4px"><a href="services/tertiary-verification">Tertiary Education Check</a></td>
        <td style="padding:4px"><?php echo $credits->credits_with_text ('tertiary'); ?></td>
    </tr>
    <tr>
        <td style="padding:4px"><a href="services/association-check">Association Check</a></td>
		<td style="padding:4px"><?php echo $credits->credits_with_text ('association'); ?></td>
    </tr>
</table>
<div class="space"></div>
<h3 class="green-heading">Example</h3>
Say you wanted to perform the following checks on an individual: ID check, Credit check, Matric check <br /><br />
</div>
</div>
<div class="row">
<div class="col-md-4" style="margin-top:10px">
<?php 
	$credits = new Credits (); 
?>
<table>
<tr>
    <td width="200">ID Check</td>
    <td><?php echo $credits->credits_with_text ('id'); ?></td>
</tr>
<tr> 
    <td>Credit Check</td>
    <td><?php echo $credits->credits_with_text ('credit'); ?></td> 
</tr>
<tr>
    <td>Matric Check</td>
    <td><?php echo $credits->credits_with_text ('matric'); ?></td>
</tr> 
<tr>
	<td colspan="2"><hr /></td>
</tr>
<tr>
	<td><strong>Total Credits required</strong></td>
	<td><strong>11 Credits</strong></td>
</tr>
</table> 
</div>
<div class="col-md-4" style="margin-top:10px">
<table>
<tr>
	<td colspan="2"><strong>Purchase 15 Credits</strong></td>
</tr>
<tr>
    <td width="200">15 Credits X R10/credit</td>
    <td>R150.00</td>
</tr>
<tr> 
    <td>VAT</td>
    <td>R21.00</td> 
</tr>
<tr>
	<td colspan="2"><hr /></td>
</tr>
<tr>
    <td><strong>Total Cost</strong></td>
    <td><strong>R171.00</strong></td>
</tr> 

</table>
</div>
<div class="col-md-4" style="margin-top:30px">
<table>
<tr>
    <td width="200">Total Credits Purchased</td>
    <td>15</td>
</tr>
<tr> 
    <td>Credits Used</td>
    <td>11</td> 
</tr>
<tr>
	<td colspan="2"><hr /></td>
</tr>
<tr>
    <td><strong>Available for Future Use</strong></td>
    <td><strong>4</strong></td>
</tr> 

</table>
</div></div>
<div style="margin-top:72px">
                	<input type="button" onclick="document.location.href='register'" class="btn btn-success btn-large" value="Register to Purchase Credits" />
                </div>
        </div>
    </div>

</div>
<div class="space"></div>
	
 <a href="#0" class="cd-top">Top</a>
