<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center;
          background-size:cover;">
    <div class="container content-header">
        Knowledge Centre
        <div class="try">
            <a href="register">
                <input type="button" class="btn btn-primary btn-nav" value="TRY NOW" />
            </a>
        </div>
    </div>
</div>
<!-- jumbotron -->


<!-- Content Below
    ================================================== -->

<div class="container">

    <main class="cd-main-content">
        <div class="cd-tab-filter-wrapper">
            <div class="cd-tab-filter">
                <ul class="cd-filters">
                    <li class="placeholder">
                        <a class="selected" href="knowledge-centre#0" data-type="all">Show All</a>
                    </li>
                    <li class="filter"><a class="selected" href="knowledge-centre#0" data-type="all">Show All</a></li>
                    <li class="filter" data-filter=".blog"><a href="knowledge-centre#0" data-type="blog">Ebook</a></li>
                    <li class="filter" data-filter=".guides"><a href="knowledge-centre#0" data-type="guides">Blog</a></li>
                </ul>
                <!-- cd-filters -->
            </div>
            <!-- cd-tab-filter -->
        </div>
        <!-- cd-tab-filter-wrapper -->

        <section class="cd-gallery">
            <ul>
            	<li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/3-top-reasons-why-you-should-not-overlook-background-screening'><img src="images/3-top-reasons-why-you-should-not-overlook-background-screening.jpg" alt="background checks" /></a>
                        <h4><a href='articles/3-top-reasons-why-you-should-not-overlook-background-screening'>3 top reasons why you should not overlook the importance of background screening</a></h4>
                        <p>
                            <?php $content = 'How to reduce employee turn-over and combat internal employee syndicates In an increasingly digitised world, tech-savvy fraudsters operating inside the workspace are finding new ways to access companies’ classified data and can defraud companies of billions. If used proactively, background screening can be a formidable tool in eradicating employee theft and fraud.';

					echo substr($content, 0, 160).'...' ?>
                        </p>
                    </div>
                </li>
                <li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/the-top-3-digitised-recruitment'><img src="images/the-top-3-digitised-recruitment.jpg" alt="background checks" /></a>
                        <h4><a href='articles/the-top-3-digitised-recruitment'>The Top 3 Digitised Recruitment Trends for 2016</a></h4>
                        <p>
                            <?php $content = 'With their unbridled thirst for success and inherent entrepreneurial skills, Generation Z entered into the job market in 2015 with a bang. In the ever-increasing digital world in which this generation thrives, recruiters have to sell their company’s ability to move with the times in order to acquire the top candidate for the position.';

					echo substr($content, 0, 160).'...' ?>
                        </p>
                    </div>
                </li>
            	<li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/using-technology-employee-engagement'><img src="images/using-technology-employee-engagement.png" alt="background checks" /></a>
                        <h4><a href='articles/using-technology-employee-engagement'>Using Technology to Enhance Employee Engagement</a></h4>
                        <p>
                            <?php $content = 'Top 3 Ways in Which Techonology Can be Used to Increase Employee Engagement. Employee engagement measurements have become a big deal for good reason; engaged employees are good for business. They lead to higher customer satisfaction, better service, increased sales, higher profits and increased returns for investors. Research conducted suggests that ';

					echo substr($content, 0, 160).'...' ?>
                        </p>
                    </div>
                </li>
                 <li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='http://www.businessessentials.co.za/services/fraudcheck/' target="_blank"><img src="images/fc-logo-block.png" alt="background checks" /></a>
                        <h4><a href='http://www.businessessentials.co.za/services/fraudcheck/' target="_blank">Fraudcheck featured by Business Essentials</a></h4>
                        <p>
                            <?php $content = 'Fraudcheck is a transactional risk management solution that runs real time data queries which includes but not limited to ID verification, pre-employment vetting, credit checks, criminal checks, deeds checks, bank verifications, and director checks across multiple partners and provides a strategic BIS overview.';

					echo substr($content, 0, 160).'...' ?>
                        </p>
                    </div>
                </li>
                <li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/referral-campaign'><img src="images/fc-logo-block.png" alt="background checks" /></a>
                        <h4><a href='articles/referral-campaign'>Fraudcheck unveils a new business referral offering</a></h4>
                        <p>
                            <?php $content = 'For each of the first 10 businesses who register with your unique code and make a purchase on Fraudcheck, you and the business you refer will each get R90 worth of credits';

					echo substr($content, 0, 160).'...' ?>
                        </p>
                    </div>
                </li>
                <li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/employee-background-checks'><img src="images/background-checks-what-lies-beneath.jpg" alt="background checks" /></a>
                        <h4><a href='articles/employee-background-checks'>Employee background checks reveal hidden truths: What lies beneath the surface?</a></h4>
                        <p>
                            <?php $content = 'When hiring new employees into an organisation, promoting staff from within or in dealing with external vendors and temporary contractors; the very last issue one expects to have to factor into the recruitment equation is fraud. Yet, as will be revealed, the initial phase of the hiring process can be a critical point at which any potential red flags can be identified;';

					echo substr($content, 0, 160).'...' ?>
                        </p>
                    </div>
                </li>
                <li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/driving-home-the-importance'><img src="images/background-checks-in-transport-industry.jpg" alt="driving home the importance" /></a>
                        <h4><a href='articles/driving-home-the-importance'>Driving home the importance of carrying out background checks on drivers in the transport industry</a></h4>
                        <p>
                            <?php $content = 'From air to road and truck to taxi, by and large, the South African transport industry covers an extensive array of systems and segments, and represents a driving force within the economy whose sole purpose is geared towards ensuring that goods as well as people are conveyed from point A to point B in the safest and most cost effective ways possible. ';

					echo substr($content, 0, 160).'...' ?>
                        </p>
                    </div>
                </li>
                <li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/3-top-factors-businesses-consider-extending-credit'><img src="images/business-credit-article.jpg" alt="business credit" /></a>
                        <h4><a href='articles/3-top-factors-businesses-consider-extending-credit'>3 top factors businesses should consider before extending credit</a></h4>
                        <p>
                            <?php $content = 'For a business it is important to have the option to extend credit or payment plans to customers or clients. Providing this option can generally drive up sales. This method of extending credit also increases the range of customers businesses can serve with their product or service in South Africa.';

                          echo substr($content, 0, 160).'...' ?>
                        </p>
                    </div>
                </li>

                <li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/7-tips-keep-a-good-credit-score'><img src="images/7-tips-credit-score.jpg" alt="credit score" /></a>
                        <h4><a href='articles/7-tips-keep-a-good-credit-score'>7 tips on how you can keep a good credit score</a></h4>
                        <p>
                            <?php $content = 'A credit score is important because it is a like a school report card which shows if you have been good in paying off any debts or accounts you owe money on. Banks and other companies that loan you money use the credit score to evaluate you financially.';

					echo substr($content, 0, 160).'...' ?>
                        </p>
                    </div>
                </li>

                <li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/online-vendor-types-of-fraud'><img src="images/Online-Vendors-and-Cybercrime-Blog.png" alt="Online Vendor Fraud" /></a>
                        <h4><a href='articles/online-vendor-types-of-fraud'>As an online vendor what types of fraud should I look out for online</a></h4>
                        <p>
                            <?php $content = 'Selling goods online is an efficient, low cost and simple way of transacting. Whether you are a private individual who occasionally sells items online or an organisation with a full online shopping store, online selling is not risk free.';

					echo substr($content, 0, 160).'...' ?>
                        </p>
                    </div>
                </li>

                <li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/matric-certificates'><img src="images/matric-certificates.jpg" alt="Matric Certificates" /></a>
                        <h4><a href='articles/matric-certificates'>Beware Fraudulent Matric Certificates in SA</a></h4>
                        <p>
                            <?php $content = 'Utilising a reputable background screening agency is the safest, most effective way to ensure that you only hire individuals with verified qualifications. FraudCheck has partnered with Umalusi to verify and supply accurate information on matric qualifications within 48 hours.';

					echo substr($content, 0, 150).'...' ?>
                        </p>
                    </div>
                </li>

                <li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/i-love-online-shopping'><img src="images/online-shopping.jpg" alt="I Love Online Shopping" /></a>
                        <h4><a href='articles/i-love-online-shopping'>I Love Online Shopping</a></h4>
                        <p>
                            <?php $content = 'Online shopping is convenient and fun; nothing beats crowd-free shopping from the comfort of your own lounge, mug of coffee in hand and the knowledge that whatever you order will be delivered straight to you. Unfortunately, there are risks associated with online shopping.  While we may be sitting in the safety of our own homes, we are in reality engaging with the world at large, albeit virtually.';

					echo substr($content, 0, 150).'...' ?>
                        </p>
                    </div>
                </li>

                <li class="mix blog check1 radio2 option3">
                    <div align="center" class="thumbnail">

                        <a href='resources/complete-guide-to-protecting-yourself-online'><img src="images/complete-guide-to-protecting-yourself-online-thumb.jpg" alt="The complete guide to protecting yourself when buying and selling online" /></a>
                        <h4><a href='resources/complete-guide-to-protecting-yourself-online'>The complete guide to protecting yourself when buying and selling online</a></h4>

                        <p>
                            <?php $content = 'Ecommerce is becoming the preferred way to shop as customers want to avoid the hustle and bustle of crowds and long queues. Online buying and selling seems very convenient but it does not come without risks. Cybercrime is not only on the increase but it continuously changes its shape and form- fraudsters are always looking for new ways to get money out of you. Don’t fall victim to cybercrime and do everything you can to protect yourself- after all, it could happen to you. Download “The complete guide to protecting yourself when buying and selling online” for free now and be one step ahead of fraudsters online!';

					echo substr($content, 0, 150).'...' ?>
                        </p>

                    </div>


                </li>

                <li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/white-collar-crime-south-africa'><img src="images/white-collar.jpg" alt="White Collar Crime in South Africa has Gone Wild" /></a>
                        <h4><a href='articles/white-collar-crime-south-africa'>White Collar Crime in South Africa has Gone Wild</a></h4>
                        <p>
                            <?php $content = 'White collar crime in South Africa has gone wild. Jeff miller acting CEO of Fraud check says it is vital for companies to conduct pre-employment screening of applicants before appointing them. Has the applicant got a valid ID number';

					echo substr($content, 0, 150).'...' ?>
                        </p>
                    </div>
                </li>

                <li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/drivers-license-for-sale'><img src="images/drivers.jpg" alt="Drivers Licenses for Sale" /></a>
                        <h4><a href='articles/drivers-license-for-sale'>Drivers Licenses for Sale</a></h4>
                        <p>
                            <?php $content = 'Where did you get your drivers licence is an extremely common question asked of South African drivers. Yes, believe it or not, fraudulent drivers licenses are a common phenomenon in our country. When it comes to employing drivers, companies need to be extra vigilant';

					echo substr($content, 0, 150).'...' ?>
                        </p>

                    </div>
                </li>

                <li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/pre-employment-screening-vital-to-employment'><img src="images/screening.jpg" alt="Pre Employment Screening is vital to the Employment Process" /></a>
                        <h4><a href='articles/pre-employment-screening-vital-to-employment'>Pre Employment Screening is vital to the Employment Process</a></h4>
                        <p>
                            <?php $content = 'South African employers now have to change their modis operandi when making employment and hiring decisions. Recently we have seen many senior high profile leaders in both corporate and government entities being caught out for lying on their CVs and job applications.  Jeff Miller the acting CEO of Fraud Check estimates';

					echo substr($content, 0, 150).'...' ?>
                        </p>

                    </div>
                </li>

                <li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/have-you-ever-been-duped-swindled-conned'><img src="images/duped.jpg" alt="Have you ever been duped, swindled or conned?" /></a>

                        <h4><a href='articles/have-you-ever-been-duped-swindled-conned'>Have you ever been duped, swindled or conned?</a></h4>
                        <p>
                            <?php $content = 'Have you ever been duped, swindled or conned? It’s not a great feeling. The word ‘con’ as in conman or confidence trickster comes from the idea that this person sets out to defraud an individual or company by first gaining his victim’s confidence or trust. One Victor Lustig actually ‘sold’ the Eiffel Tower for scrap metal. Andre Poisson, duped by forged government credentials, the limousine ride to the site, and the tale that the city';

					echo substr($content, 0, 180).'...' ?>
                        </p>
                    </div>
                </li>

                <li class="mix guides check1 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/sweat-baby-sweat-body-language-to-look-out-for'><img src="images/sweat.jpg" alt="Sweat Baby Sweat - Body language and the worrying signs you should look out for" /></a>
                        <h4><a href='articles/sweat-baby-sweat-body-language-to-look-out-for'>Sweat Baby Sweat - Body language and the worrying signs you should look out for</a></h4>
                        <p>
                            <?php $content = 'Body language is a real thing. Even though it’s the middle of winter and everyone else in this interview is shivering, your candidate seems to be quite worked up. Deceiving someone is hard work. They say it takes a lot more effort to frown than to smile';

					echo substr($content, 0, 150).'...' ?>
                        </p>
                    </div>
                </li>

                <li class="mix guides check1 radio3 option4">
                    <div class="thumbnail1" align="center">
                        <a href='articles/wake-up-and-smell-the-roses'><img src="images/coffee.jpg" alt="Wake up and smell the roses. (Or the coffee. Whichever you prefer.)" /></a>
                        <h4><a href='articles/wake-up-and-smell-the-roses'>Wake up and smell the roses. (Or the coffee. Whichever you prefer.)</a> </h4>
                        <p>
                            <?php $content = 'It’s pretty difficult to ignore something that smells bad. It consumes you, and in almost an instant you react. Whether you block your nose, gag a little, or fan your face, your reaction to a bad smell tells you instantly that something is not right';

					echo substr($content, 0, 150).'...' ?>
                        </p>

                    </div>
                </li>

                <li class="mix guides check3 radio3 option2">
                    <div class="thumbnail1" align="center">
                        <a href='articles/believe-it-or-not-a-cv-can-lie'><img src="images/cv-can-lie.jpg" alt="Believe it or not: A CV can lie" /></a>
                        <h4><a href='articles/believe-it-or-not-a-cv-can-lie'>Believe it or not: A CV can lie</a> </h4>
                        <p>
                            <?php $content = 'Why do companies ask for a CV before meeting with someone? So that they don’t waste time interviewing people who do not have the necessary skill set, experience or expertise. The idea of a CV is wonderful in theory, verifying identity and finding about the applicant at the same time. But often, the reality of receiving CV’s turns out to be far less helpful than one would like it to be. This is because a CV can lie';

					echo substr($content, 0, 150).'...' ?>
                        </p>

                    </div>
                </li>

                <li class="mix guides check3 radio2 option4">
                    <div class="thumbnail1" align="center">
                        <a href='articles/dont-judge-a-book-by-its-cover'><img src="images/dont_judge.jpg" alt="Don't Judge a Book by its Cover" /></a>

                        <h4><a href='articles/dont-judge-a-book-by-its-cover'>Don&acute;t Judge a Book by its Cover</a> </h4>
                        <p>
                            <?php $content = 'There’s a reason this is the most clichéd saying in the world (we Googled it, and yes, it has been voted the biggest cliché ever). Looks can be deceiving, how could one truly verify an identity? We’ve been taught that confidence is a good thing, and while this is true, often confidence can turn into cockiness or even a cover up for someone’s true personality';

					echo substr($content, 0, 150).'...' ?>
                        </p>
                    </div>
                </li>

                <li class="mix guides check1 radio2 option3">
                    <div class="thumbnail1" align="center">
                        <a href='articles/one-word-google'><img src="images/google.jpg" alt="One word: Google." /></a>
                        <h4><a href='articles/one-word-google'>One word: Google.</a> </h4>
                        <p>
                            <?php $content = 'These days, we have access to endless amounts of information; you could potentially find good background information on anyone or at the very least, verify identity. The information found online does contain information that is useless (think “ten steps to learning Gangnam Style”), while some information can be pretty useful';

					echo substr($content, 0, 150).'...' ?>
                        </p>
                    </div>
                </li>

                <li class="mix guides check2 radio2 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/the-employment-evolution'><img src="images/emp-revolution.jpg" alt="The Employment Evolution!" /></a>
                        <h4><a href='articles/the-employment-evolution'>The Employment Evolution!</a></h4>
                        <p>
                            <?php $content = 'Over the years, the process of recruiting has radically evolved. Back in the day, there were a couple of dedicated newspapers that would target audiences looking for jobs. That was it! If your dream job didn’t appear for months, there was no hope';

					echo substr($content, 0, 150).'...' ?>
                        </p>
                    </div>
                </li>

                <li class="mix guides check2 radio3 option3">
                    <div class="thumbnail1" align="center">
                        <a href='articles/the-costs-of-hiring-the-right-and-wrong-people'><img src="images/hire.jpg" alt="The Costs of Hiring the Right and Wrong People" /></a>
                        <h4><a href='articles/the-costs-of-hiring-the-right-and-wrong-people'>The Costs of Hiring the Right and Wrong People</a></h4>
                        <p>
                            <?php $content = 'Employing someone to help grow your business is a tricky task. Entrepreneurs or business owners cannot afford to lose money on hiring the wrong people; neither can they lose money by not having enough staff to keep the business running successfully';

					echo substr($content, 0, 150).'...' ?>
                        </p>


                    </div>
                </li>

                <li class="mix guides check1 radio3 option2">
                    <div class="thumbnail1" align="center">
                        <a href='articles/the-big-five'><img src="images/big-5.jpg" alt="The Big Five" /></a>
                        <h4><a href='articles/the-big-five'>The Big Five</a></h4>
                        <p>
                            <?php $content = 'A common method to use is to write an advert of the job description and position you are looking to fill, and posting it online. In the South African market, there are many platforms that offer this service, some requiring a form of identity verification from the candidate';

					echo substr($content, 0, 180).'...' ?>
                        </p>
                    </div>
                </li>

                <li class="mix guides check3 radio2 option4">
                    <div class="thumbnail1" align="center">
                        <a href='articles/toxic-people-to-avoid-hiring'><img src="images/toxic.jpg" alt="Toxic people to avoid hiring" /></a>
                        <h4><a href='articles/toxic-people-to-avoid-hiring'>Toxic people to avoid hiring</a></h4>
                        <p>
                            <?php $content = 'There are certain personality traits that your company should be cautious about hiring. This can help save your company time and money. We like to think of these personalities as toxic people';

					echo substr($content, 0, 150).'...' ?>
                        </p>


                    </div>
                </li>
                <li class="mix guides check3 radio3 option1">
                    <div class="thumbnail1" align="center">
                        <a href='articles/writing-a-captivating-job-description'><img src="images/Writing-a-Captivating-Job-Description.jpg" alt="Writing a Captivating Job Description" /></a>
                        <h4><a href='articles/writing-a-captivating-job-description'>Writing a Captivating Job Description</a> </h4>
                        <p>
                            <?php $content = 'If you have ever been online to have a look at job postings, you were browsing the relevant jobs portal searching for a suitable candidate while keeping in mind that probably none of them had any sort of checks to verify their identity';

					echo substr($content, 0, 150).'...' ?>
                        </p>

                    </div>
                </li>
                <li class="mix blog check1 radio2 option3">
                    <div align="center" class="thumbnail">

                        <a href='resources/where-did-all-the-people-go'><img src="images/where-did-all-the-people-go-thumb1.jpg" alt="Where did all the people go?" /></a>
                        <h4><a href='resources/where-did-all-the-people-go'>Where did all the people go ?</a></h4>

                        <p>
                            <?php $content = 'Some things are easier to find than others. Looking for the right people to interview for a job would fall on the list of less-easy-to-find things. Wouldn’t it be a relief to know that there are certain avenues you could visit to find quality people who would be perfect for the job at hand? That would make the interview process a lot less daunting. In this guide we will discuss all the platforms your business can use to help find the right people to interview, as well as all their strengths and weaknesses.';

					echo substr($content, 0, 190).'...' ?>
                        </p>

                    </div>


                </li>
                <li class="mix blog check2 radio2 option2">
                    <div align="center" class="thumbnail">
                        <a href='resources/where-did-all-the-people-go'><img src="images/ultimate-guide-to-hiring-thumb1.jpg" alt="The Ultimate Guide to Hiring" /></a>
                        <h4><a href='resources/where-did-all-the-people-go'>The Ultimate Guide to Hiring</a></h4>
                        <p>
                            <?php $content = 'Employing someone is not an easy task. There are the tons of CV’s to sift through, the endless rounds of interviews and finally, the big decision. Make sure your company hires trustworthy employees with this easy-to-use hiring guide.Fraudcheck has compiled this guide to help steer you in the direction of safer hiring, ensuring that your company maintains a strong circle of trust.In this guide we will demonstrate all the need-to-knows during the interview process. Think you’ve found the one? Think again. Background screening – which, let’s be honest, is usually not at the top of our to-do lists – is a crucial part of the employment process.';

					echo substr($content, 0, 170).'...' ?>
                        </p>
                    </div>
                </li>

                <li class="mix blog check1 radio2 option3">

                    <br>
                    <br>
                    <br>
                    <br>
                </li>

                <li class="mix blog check1 radio2 option3">



                </li>

                <li class="mix blog check1 radio2 option3">


                </li>

                <li class="mix blog check1 radio2 option3">



                </li>

            </ul>
            <div class="cd-fail-message">No results found</div>
        </section>
        <!-- cd-gallery -->



        <div class="space"></div>
    </main>
</div>

<a href="#0" class="cd-top">Top</a>
