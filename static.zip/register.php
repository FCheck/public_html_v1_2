
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; background-size:cover;">
  <div class="container content-header">
    Register to Use FraudCheck
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
   <div id="collectdata"> 
<div class="container">
	<div class="page-header">
    	<h2 class="green-heading"><strong>Getting Started</strong></h2>    
    </div>
     <div class="col-md-12 column">
                        <div class="row clearfix">
    <p class="steptext">Getting started with FraudCheck is quick and easy, just follow the simple steps below. <!--Register now and get a <span style="color:#43a447; font-weight:bold;">FREE ID Check</span>!--></p>
    <div class="row">
        <div class="col-md-6">
            <div class="space"></div>
            
                <form method="post" id="regform" action="buy-credits">
                <div id="step1">
                    <div class="row">
                    	<div class="col-md-6 " style="margin-bottom:10px">
                        	<input type="text" class="form-control" id="firstName" placeholder="First Name" name="firstName" style="height:45px" >
                        </div>
                        <div class="col-md-6" style="margin-bottom:10px">
                            <input type="text" class="form-control" id="surname" placeholder="Surname" name="surname" style="height:45px" >
                        </div>
                    </div>
                    <div class="row">
                    	<div class="col-sm-12 " style="margin-bottom:10px">
                        	 <input type="text" class="form-control" id="emailAddress" placeholder="Email Address" name="email" style="height:45px" >
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12" style="margin-bottom:10px">
                            <input type="text" class="form-control" id="idNumber" placeholder="ID Number" name="idNumber" style="height:45px" >
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-sm-12" style="margin-bottom:10px">
                            <input type="tel" mask="999-999-9999" class="form-control" id="userPhones" placeholder="Cellphone Number" name="cellNo" style="height:45px" >
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-sm-6" style="margin-bottom:10px">
                            <input type="password" class="form-control" id="password" placeholder="Choose Password" name="password" style="height:45px" >
                        </div>

                        <div class="col-sm-6" style="margin-bottom:10px">
                            <input type="password" class="form-control" id="passwordconf" placeholder="Confirm Password" name="passwordconf" style="height:45px" >
                        </div>
                    </div>
                    
                    <div class="row">
                    	<div class="col-sm-6" style="margin-bottom:10px">
                        	<h2 class="green-heading" style="margin-top:6px;margin-left:5px;">Account Type:</h2>
                        </div>
                        <div class="col-sm-3" style="margin-bottom:10px">
                        <input class="displaynone acc_type" type="radio" id="individual2" name="acc_type" value="2" onclick="setRegType (2)">
                            <label for="individual2" class="registerradio" style="float:right">Business</label>
                        </div>

                        <div class="col-sm-3" style="margin-bottom:10px">
                            <input class="displaynone acc_type" type="radio" id="individual1" name="acc_type" value="1" onclick="setRegType (1)">
                            <label for="individual1" class="registerradio">Individual</label>
                        </div>
                    </div>
                    <div class="row businessdata">
                        <div class="col-sm-6" style="margin-bottom:10px">
                            <input type="text" class="form-control" id="companyName" placeholder="Business Name" name="companyName" style="height:45px" >
                        </div>
                        <div class="col-sm-6" style="margin-bottom:10px">
                            <input type="text" class="form-control" id="companyPhoneNo" placeholder="Telephone Number" name="companyPhoneNo" style="height:45px" >
                        </div>
                        <div class="col-sm-12" style="margin-bottom:10px">
                        <?php
						$codeInsert = "";
						if (!empty ($q[1]))
						{
							$codeInsert = "value='".strtoupper ($q[1])."'";
						}
						?>
                            <input type="text" class="form-control" id="referralCode" placeholder="Referral Code (optional)" name="referralCode" style="height:45px" <?php echo $codeInsert; ?> >
                        </div>
                    </div>
           
                    <div class="row">
                        <div align="center" style="margin-top:20px">
                            <input type="button" class="btn-primary btn-lg" value="Register" onclick="change_step(2)" />
                        </div>
                    </div>
                 </div>
                 <div id="step2">
                 	
                 	<div class="row">
                    	<div class="col-sm-3" style="margin-bottom:10px">
                        	
                        </div>
                    	<div class="col-sm-6" style="margin-bottom:10px">
                        	<img src="/images/img/otp.png" />
                        	<input type="text" class="form-control" id="OTP" placeholder="One Time Pin" name="OTP" style="height:45px" >
                        </div>
                    	<div class="col-sm-3" style="margin-bottom:10px">
                        	
                        </div>
                    </div>
                    <div class="row">
                        <div align="center" style="margin-top:20px">
                            <!--<input type="button" class="btn-primary btn-lg" value="Proceed" onclick="reg_run_check()" />-->
                            <input type="button" class="btn-primary btn-lg" value="Confirm" onclick="verify_otp ()" />
                        </div>
                    </div>
                    <div class="row">
                    	<p>&nbsp;</p>
                    	<p align="center">Didn't receive an OTP? <a href="javascript:open_resend()">Click here</a></p>
                    </div>
                    <div class="row resend">
                    	<p align="center">Confirm your cellphone number below and click Re-send</p>
                    	<div class="col-sm-2" style="margin-bottom:10px">
                        	
                        </div>
                        <div class="col-sm-6" style="margin-bottom:10px">
                    		<input type="text" class="form-control" id="tel-otp" placeholder="Cellphone Number" name="tel-otp" style="height:45px" >
                        </div>
                        <div class="col-sm-2" style="margin-bottom:10px">
                        	<input type="button" class="btn-primary btn-lg" value="Re-Send" onclick="resend_otp()" style="height:45px" />
                        </div>
                        <div class="col-sm-2" style="margin-bottom:10px">
                        	
                        </div>
                    </div>
                 </div>
                </form>
            <script type="text/javascript">
				var __ss_noform = __ss_noform || [];
				__ss_noform.push(['baseURI', 'https://app-9IDAHGXA.sharpspring.com/webforms/receivePostback/MzMwNbQwBQA/']);
				__ss_noform.push(['endpoint', 'd2b79312-ff5b-4196-8071-8e4305834a16']);
				__ss_noform.push(['form', 'regform']); 
				__ss_noform.push(['submitType', 'manual']);
			</script>
			<script type="text/javascript" src="https://koi-9IDAHGXA.sharpspring.com/client/noform.js?ver=1.24" ></script>



        </div>
        <div class="col-md-6 mobinodisplay">
            <div style="margin-top:7px; margin-bottom:7px; text-align:justify;">&nbsp;</div>
            <div class="container space">
                <div class="row">
                    <div class="col-md-1 text-center">
                        <img src="/images/img/bullet-1.png" id="point1" class="img-responsive">
                    </div>
                    <div class="col-md-5">
                        <p class="activetext textstep1">Fully complete the registration form to the left and then click Register</p>
                    </div>
                </div>
            </div>
            
            
            <div class="container space">
                <div class="row">
                    <div class="col-md-1 text-center">
                        <img src="/images/img/bullet-2-inactive.png" id="point2" class="img-responsive">
                    </div>
                    <div class="col-md-5">
                        <p class="inactivetext textstep2">You will receive a One Time Pin to your cellphone. Enter the PIN to confirm your registration</p>
                    </div>
                </div>
            </div>
            
            <div class="container space">
                <div class="row">
                    <div class="col-md-1 text-center">
                        <img src="/images/img/bullet-3-inactive.png" id="point3" class="img-responsive">
                    </div>
                    <div class="col-md-5">
                        <p class="inactivetext textstep3" >Confirm your email address and start running checks!</p>
                    </div>
                </div>
            </div>
            
            
        </div>
    </div></div></div>
</div>
</div>
<div class="space"></div>
<div id="runchecks" style="display:none; position:absolute; top:400px;">
 	<div align="center" class="container">
    	<div class="page-header green-heading">
            Please wait while we process your registration.
        </div>
        <div class="space"></div>
    	<img src="/images/img/runcheck.gif" /><br /><br />
    </div>

	<div class="space"></div>
    <div class="space"></div>
    <div class="space"></div>
    <div class="space"></div>
    <div class="space"></div>
    <div class="space"></div>
	<div class="space"></div>
</div>
	
<a href="#0" class="cd-top">Top</a>
