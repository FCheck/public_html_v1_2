
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center;
          background-size:cover;">
  <div class="container content-header">
    Pricing

    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
<div class="container">
<div class="page-header">
    	<h2 class="green-heading"><strong>Pre-paid Credit Purchase</strong></h2>
    </div>
<div class="container space">
    	<div class="row">
            <div class="col-md-12">
            <p>The FraudCheck portal has been developed using a pre-paid credit system for your convenience. In order to begin using Fraud Check, please see the available pre-paid bundles below: &nbsp;&nbsp;&nbsp;<br /><br /><strong><img src="images/question.png" /> Not sure what this means? <a href="purchase-credits/#explanation">Click here</a></strong></p>
<br /></div>
            <div class="col-md-12">
            	<div class="row clearfix">
                   <div class="col-md-3   column">
                   		<div class="top_div">
                        	Micro
                        </div>
                        <div class="mid_div">
                        	10 credits
                            <hr>
                            Valid for 60 days
                            <hr>
                            <span class="price">R145.00 <small>incl. VAT</small></span>
                            <br><br> <br>

                            <div class="padding2"></div>
                            <div class="button"><a href="/register">Sign Up</a></div>
                        </div>
                        <div class="bot_div">
                        <br>
                        Real time checks
                        <hr>
                        Full reporting
                        <hr>
                        Email support
                        <hr>
                        No Monthly Retainer
                        <br/><br>
                        </div>
                   </div>
                   <div class="col-md-3 top   column">
                  		<div class="top_div">
                        	Basic
                        </div>
                        <div class="mid_div">
                        	30 credits
                            <hr>
                            Valid for 360 days
                            <hr>
                            <span class="price">R405.00 <small>incl. VAT</small>
                            <br>
                            <small>10 % savings</small>
                            </span>
                            <br><br>
                            <div class="button"><a href="/register">Sign Up</a></div>
                        </div>
                        <div class="bot_div">
                        <br>
                        Real time checks
                        <hr>
                        Full reporting
                        <hr>
                        Email &amp; Telephone support
                        <hr>
                        No Monthly Retainer
                        <br/><br>
                        </div>
                   </div>
                   <div class="col-md-3   column">
                   		<div class="top_div">
                        	Pro
                        </div>
                        <div class="mid_div">
                        	100 credits
                            <hr>
                            Does not expire
                            <hr>
                             <span class="price">R1200.00 <small>incl. VAT</small>
                            <br>
                            <small>20 % savings</small>
                            </span>
                            <br><br>
                            <div class="button"><a href="/register">Sign Up</a></div>
                        </div>
                        <div class="bot_div">
                        <br>
                        Real time checks
                        <hr>
                        Full reporting
                        <hr>
                        Email &amp; Telephone support
                        <hr>
                        No Monthly Retainer
                        <br/><br>
                        </div>
                   </div>
                   <div class="col-md-3 top  column">
                   		<div class="top_div">
                        	Enterprise
                        </div>
                        <div class="mid_div">
                        	Enterprise Solutions- tailor made for Companies with large volume.
                            <hr>
                            API Integration
                            <hr>
                            SAAS (Software as a service)

                           <div class="padding3"></div>
                            <div class="button"><a href="/contact">Contact Us</a></div>
                        </div>
                        <div class="bot_div">
                        <br>
                        API integration -Fraudcheck Services into your Internal or Client Facing Systems
                        <hr>
                        Customised pricing
based on volume
                        <hr>
                        Billing in arrears
                        <hr>
                        White-labelled solutions
                        <br/><br>
                        </div>
                   </div>

            	</div>
            </div>
            <div class="col-md-11">
            	<div class="heading">Questions about pricing? Call us at 011 262 5252 </div>
                <br>
            </div>
            <div class="col-md-12">
            	<div class="line">&nbsp;</div>
                <br>
                <div class="sub_heading"><a name="explanation"></a>What are credits and how do I use them?</div>
                <br>
            </div>

<div class="col-md-11">
<div class="text">All Fraud Check services are managed through a pre-paid credit system. Think of it like getting a data bundle for your cell phone – first you buy a bundle of data, and then as you use the internet your data balance goes down. Similarly, once you purchase a credit bundle from Fraud Check, you will have a balance of credits which can be used to run the various checks offered. Once your bundle runs out, you may top it up with a new bundle. Each check requires the following number of credits:</div>
<div class="space"></div>
<?php
	$credits = new Credits ();
?>

<table class="grey" >
	<tr>
        <td  class="td1"><a href="services/id-check">ID Check</a>

        	<div class="line1"></div>

        </td>
        <td class="td2"><?php echo $credits->credits_with_text ('id'); ?> (R10)

        	<div class="line2"></div>
        </td>
    </tr>
    <tr>
        <td class="td1"><a href="services/credit-check">Credit Check</a>
        	<div class="line1"></div>
        </td>
        <td class="td2"><?php echo $credits->credits_with_text ('credit'); ?> (R30)
        	<div class="line2"></div>
        </td>
    </tr>
    <tr>
        <td class="td1"><a href="services/credit-check">Credit Check With Payment Profile</a>
        	<div class="line1"></div>
        </td>
        <td class="td2"><?php echo $credits->credits_with_text ('payment'); ?> (R60)
        	<div class="line2"></div>
        </td>
    </tr>
    <tr>
        <td class="td1"><a href="services/criminal-check">Criminal Check</a>
        	<div class="line1"></div>
        </td>
        <td class="td2">R114.00
        	<div class="line2"></div>
        </td>
    </tr>
    <tr>
        <td class="td1"><a href="services/drivers-license-check">Drivers License Check</a>
        	<div class="line1"></div>
        </td>
        <td class="td2"><?php echo $credits->credits_with_text ('drivers'); ?> (R60)
        	<div class="line2"></div>
        </td>
    </tr>
    <tr>
        <td class="td1"><a href="services/matric-verification">Matric Check</a>
        	<div class="line1"></div>
        </td>
        <td class="td2"><?php echo $credits->credits_with_text ('matric'); ?> (R60)
        	<div class="line2"></div>
        </td>
    </tr>
    <tr>
        <td class="td1"><a href="services/tertiary-verification">Tertiary Education Check</a>
        	<div class="line1"></div>
        </td>
        <td class="td2"><?php echo $credits->credits_with_text ('tertiary'); ?> (R60)
        	<div class="line2"></div>
        </td>
    </tr>
    <tr>
        <td class="td1"><a href="services/association-check">Association Check</a>
        	<div class="line1"></div>
        </td>
		<td class="td2"><?php echo $credits->credits_with_text ('association'); ?> (R60)
        	<div class="line2"></div>
        </td>
    </tr>
    <tr>
        <td class="td1"><a href="services/association-check">Bank Account Verification</a>

        </td>
		<td class="td2"><?php echo $credits->credits_with_text ('bank'); ?> (R10)</td>
    </tr>
</table>
<div class="space"></div>
<div class="sub_heading">Example</div>
As an example, if you wanted to perform an ID check, Credit check and Matric check on a single individual, the check would require the following number of credits: <br /><br />
</div>
</div>
<div class="row">
<div class="col-md-4" style="margin-top:10px">
<?php
	$credits = new Credits ();
?>
<table class="grey">
<tr>
    <td class="td1"><span class="a">ID Check</span>
    	<div class="line1"></div>

    </td>
    <td class="td2"><?php echo $credits->credits_with_text ('id'); ?> (R10)

    	<div class="line2"></div>
    </td>
</tr>
<tr>
    <td class="td1"><span class="a">Credit Check</span>
    <div class="line1"></div>
    </td>
    <td class="td2"><?php echo $credits->credits_with_text ('credit'); ?> (R30)
    	<div class="line2"></div>
    </td>
</tr>
<tr>
    <td class="td1"><span class="a">Matric Check</span>
    <div class="line1"></div><div class="line3"></div>
    </td>
    <td class="td2"><?php echo $credits->credits_with_text ('matric'); ?> (R60)
    	<div class="line2"></div><div class="line4"></div>
    </td>
</tr>
<tr>
	<td class="td1"><span class="a">Total Credits required</span>

    </td>
	<td class="td2"><span class="b">11 Credits (R110)</span>

    </td>
</tr>
</table>
</div>

</div>
<div style="margin-top:72px">
                	<input type="button" onclick="document.location.href='register'" class="btn btn-success btn-large" value="Register to Purchase Credits" />
                </div>


        </div>
    </div>

</div>
<div class="space"></div>

<a href="#0" class="cd-top">Top</a>
