
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(/images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    Login
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
<div class="container">
	<div class="page-header">
    	<h2 class="green-heading"><strong>Enter Login Details</strong></h2>
        </div> 
        <form method="post" action="processlogin.php">
                                <p><input type="text" name="email" class="form-control" placeholder="Email Address" style="width:300px" /></p>
                                <p><input type="password" name="password" class="form-control" placeholder="Password" style="width:300px" /></p>
                                <p><input type="submit" class="btn btn-success" value="Login" /></p>
                                <?php if (!empty ($q[1]))
								{ 
									$var = $q[1];
									if (!empty ($q[2]))
									{ 
										$var .= "/".$q[2];
										if (!empty ($q[3]))
										{
											$var .= "/".$q[3];
										}
									}
								?>
                                <input type="hidden" name="referral" value="<?php echo $var; ?>" />
                                <?php } ?>
                                <p><a href="reset-password">Forgot Password</a></p>
                            </form>   
    
 	<div class="space"></div>
    
</div>
<div class="space"></div>
	
 <a href="#0" class="cd-top">Top</a>
