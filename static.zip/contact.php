
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
   Contact Us
   <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
    
    <div class="container">

    	<div class="row space">
            <div class="col-md-7">
             <?php
			 if (!empty ($_POST ['requestType']))
			 {
				 $api = new Api ();
				$url = "userdata/contact?firstName=".$_POST ['contactName']."&companyName=".$_POST ['companyName']."&emailAddress=".$_POST ['email']."&requestType=".$_POST ['requestType']."&subject=".$_POST ['subject']."&message=".$_POST ['message'];
				$variables ['test'] = "test";
				$request = json_encode ($variables);
				$return = $api->submit_api_request ($request, $url, 1);
				$response = json_decode ($return, true);
				//echo $return;
			 }
			?>
             <div class="page-header green-heading">
                <strong>Contact Details</strong>
             </div>
			  <div class="space"></div>
             
            <form class="form-horizontal" method="post" action="contact-thank-you">
              
              <div class="form-group">
                <label for="inputFirstName" class="col-sm-2 control-label">Company Name</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="inputFirstName" name="companyName" placeholder="Company Name">
                </div>
              </div>
              
              <div class="form-group">
                <label for="inputSurname" class="col-sm-2 control-label">Your Name</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="inputSurname" name="contactName" placeholder="Your Name">
                </div>
              </div>
              
              <div class="form-group">
                <label for="inputEmail" class="col-sm-2 control-label">Email</label>
                <div class="col-sm-10">
                  <input type="email" class="form-control" id="inputEmail" name="email" placeholder="Email">
                </div>
              </div>
              
              <div class="page-header green-heading">
                 <strong>Query</strong>
              </div>
              
              <div class="space"></div>
              
              <div class="form-group">
              <label for="inputRequestType" class="col-sm-2 control-label">Request Type</label>
                <div class="col-sm-10">
                  <select class="form-control" class="requestType">
                  <option value="Support">Support</option>
                  <option value="Sales">We are interested in your services - please contact us</option>
                  <option value="Billing">Payment Query</option>
                </select>
                </div>
              </div>
              
              <div class="form-group">
                <label for="inputSubject" class="col-sm-2 control-label">Subject</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="inputSubject" class="subject" placeholder="Subject">
                </div>
              </div>
              
              <div class="form-group">
                <label for="inputSubject" class="col-sm-2 control-label">Message</label>
                <div class="col-sm-10">
                	<textarea class="form-control" rows="3" id="inputMessage" class="message" placeholder="Message"></textarea>
                </div>
              </div>
              
              <div class="form-group">
                
                <div class="col-sm-12" align="center">
                	<input type="submit" value="Send" class="btn btn-primary" />
                </div>
              </div>
              
            </form>

          </div>
          <div class="col-md-1"></div>
          <div class="col-md-3">

            <br>
			<br>
          	<h4>Support Desk</h4> 

            <strong>Call:</strong> 011 262 5252
            <br>
            <strong>Email:</strong> <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>
            <br>
            <strong>Email:</strong> <a href="mailto:support@fraudcheck.co.za">sales@fraudcheck.co.za</a>
            <br>
            <strong>Documents/Verifications Email:</strong> <a href="mailto:verify@fraudcheck.co.za">verify@fraudcheck.co.za</a>
            <br /><Br /><br /><Br />
            <h4>Physical Address</h4>
            <br>
            <strong>FRAUDCHECK OFFICES:</strong> <a href="https://goo.gl/maps/drqzZB45NfM7qmXj7">Get-Directions</a>
            Pinmill Farm Office Park, Building 2,<br />
            164 Katherine Street,<br />
            Strathavon,<br />
            Sandton,<br />
            2196 
          </div>
          
        </div>
    </div>

	<div class="space"></div>
    
    
   <a href="#0" class="cd-top">Top</a>
