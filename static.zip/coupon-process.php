
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    Special Offer
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
<div class="container">
<?php
if (isset ($_POST  ['promo']))
{
	$code = $_POST  ['promo'];
	switch ($code)
	{
		case 'FRI45':
			//give 1 free credit
			//first log user in
			$GLOBALS ['user'] = new User (-1);
			$GLOBALS ['user']->email = $_POST ['email'];
			$GLOBALS ['user']->get_user_by_email ();
			$_SESSION ['login'] = true;
			$_SESSION ['user_id'] = $GLOBALS ['user']->get_user_id();
			
			$transactionId = $GLOBALS ['user']->create_purchase_reference();
			$check = $GLOBALS ['user']->confirm_transaction ($transactionId, 1, 0, "Coupon Redeemed - FRI45", 2);//status 2 = approved
			$output = "You have redeemed your 1 Free Credit. This can be used to run an ID check on Fraudcheck, please <a href='check-someone'>click here</a> to run your free ID check now!";
		break;
		case 'FR896':
			//give 10 free credit
			
			$transactionId = $GLOBALS ['user']->create_purchase_reference();
			$check = $GLOBALS ['user']->confirm_transaction ($transactionId, 10, 0, "Coupon Redeemed - FR896", 2);//status 2 = approved
			$output = "You have redeemed your 10 Free Credits. <a href='check-someone'>Click here</a> to run your free checks now!";
		break;
	}
	?>
    <div class="page-header">
    	<h2 class="green-heading"><strong>Whoop Whoop!</strong></h2> 
        <p><?php echo $output; ?></p>   
    </div>
    <?php
}
else
{
?>
	<div class="page-header">
    	<h2 class="green-heading"><strong>Error</strong></h2> 
        <p>Coupon not valid. Sorry!</p>   
        <p>If you believe the coupon you entered should be valid, please <a href="contact">contact us</a></p>
    </div>
    
 	
    
<?php
}
?>

</div>
<div class="space"></div>
	
 <a href="#0" class="cd-top">Top</a>
