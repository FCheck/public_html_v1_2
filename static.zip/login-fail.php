
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(/images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    Login Fail
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
<!--<div class="alert alert-warning" style="margin-bottom:0px">-->
    <!--<strong>Please note:</strong> <span id="warntxt">Our portal services are currently offline. We apologise for the inconvenience and promise to return the website back to normal as soon as possible.</span>-->
<!--</div>-->

<div class="container">
	<div class="page-header">
    	<h2 class="green-heading"><strong>Email or Password Incorrect</strong></h2> 
        <p>Please check that your email address and password is correct and try log in again. If you do not remember your password, please <a href="reset-password">click here</a></p>   
    </div>
    <form method="post" action="processlogin.php">
                                <p><input type="text" name="email" class="form-control" placeholder="Email Address" style="width:300px" /></p>
                                <p><input type="password" name="password" class="form-control" placeholder="Password" style="width:300px" /></p>
                                <p><input type="submit" class="btn btn-success" value="Login" /></p>
                                </form>
 	<div class="space"></div>
    
</div>
<div class="space"></div>
	
 <a href="#0" class="cd-top">Top</a>
