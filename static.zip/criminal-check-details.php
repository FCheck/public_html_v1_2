
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
   Criminal Checks
   <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
    
    <div class="container">

    	<div class="row space">
            <div class="col-md-7">

             <div class="page-header green-heading">
                <strong>How do I run a criminal check</strong>
             </div>
             
             
          <p style="text-align:justify">In order to run a criminal check, the candidate has to have their fingerprints captured by a trained Fraudcheck representative. This can either be done by sending the candidate to our offices in Sandton (please <a href="contact">contact us</a> to arrange a suitable time), or alternatively we can come to your offices within the Johannesburg or Cape Town regions with the relevant equipment to take fingerprints on site. Once fingerprints have been captured, you will be able to view the status of your criminal checks <a href="criminal-list">here</a>.</p>
          <p style="text-align:justify">To book an appointment to capture fingerprints, please contact our support desk:<br /><br />
          <strong>Call:</strong> 011 262 5252
          <br>
            <strong>FRAUDCHECK OFFICES:</strong> <a href="https://goo.gl/maps/drqzZB45NfM7qmXj7">Get-Directions</a>
            <br>
            <strong>Email:</strong> <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>
            <div class="page-header green-heading">
                <strong>Why do I need to capture fingerprints?</strong>
             </div>
             
             
          <p style="text-align:justify">In South Africa, it is a legal requirement to capture an individual&acute;s fingerprints before one can legally run a criminal check against them. This requirement is set by government and is in place to prevent fraud and unauthorised checks against individuals.</p>

          </div>
          <div class="col-md-1"></div>
          <div class="col-md-3">
            <br>
			<br>
          	<h4>Support Desk</h4> 

            <strong>Call:</strong><a href="tel:+272625252">011 262 5252</a> 
            <br>
            <strong>Email:</strong> <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>
          </div>
          
        </div>
    </div>

	<div class="space"></div>
    
    
   <a href="#0" class="cd-top">Top</a>
