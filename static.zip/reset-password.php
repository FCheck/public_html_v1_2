
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    Reset Password
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
<div class="container">
	<div class="page-header">
    	<h2 class="green-heading"><strong>Enter Email Address</strong></h2> 
        <p>Please enter your email address below to reset your password:</p>  
        <form method="post" action="reset-password-thanks"> 
        <input type="text" name="email" class="form-control" style="width:300px" /><br />
        <button class="btn-primary btn-lg">Reset</button>
        </form>
    </div>
    
 	<div class="space"></div>
    
</div>
<div class="space"></div>
	
 <a href="#0" class="cd-top">Top</a>
