
<!-- Header Image
    ================================================== -->
<div class="jumbotron subheadbanner">
  <div class="container content-header">
    <h1>Fraudcheck for Your Business</h1>
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
    
    <div class="container space">
    	<div class="row">
            <div class="col-md-12">
            	<h2 class="green-heading">Business Services</h2>
            	<h3 class="green-heading">Pre-Employment Screening</h3>

                <p><span class="service-question">A little white lie doesn’t hurt anyone, does it?</span></p>
                
                <p>It is estimated that between 10% and 25% of applicants submit forged or falsified Matric or tertiary qualifications. Moreover candidates fail to disclose criminal records or judgements for bad debts. While these omissions may be commonplace, they are considered to be fraud.  CV or resume fraud causes serious negative financial and reputational repercussions for your organisation.</p>
                
                <p>FraudCheck offers you, the recruiter, employer or labour broker a comprehensive pre-employment background checking service. From the FraudCheck ID Check, to Qualification Verification, Criminal Checks and Credit Checks, the FraudCheck platform provides you with peace of mind and the security of knowing who you are actually dealing with. Information is presented in a single, interpreted report to ensure objectivity and eliminate hours of sifting through multitudes of verification reports.</p>
                
                
                <h3 class="green-heading">Creditworthiness Checks</h3>
                
                <p><span class="service-question">Do you grant loans or other forms of credit? Are you in the business of managing property leases?</span></p>
                
                <p>Bad debts or defaulting tenants could ruin your business. </p>
                
                <p>FraudCheck Credit Check will ensure that you are protected from the risks and costs of dealing with individuals with poor credit history and increase your ability to do business with reliable individuals. FraudCheck sources its information directly from major reputable South African credit bureaus and unique scoring system will instantaneously interpret the information and provide you with an immediate and objective result. </p>
                
                
                <h3 class="green-heading">Fraud Protection</h3>
                <p><span class="service-question">Do you need to make decisions about people quickly in a competitive market? </p>
                <p>Identity fraud, fraudulently stated qualifications or fake professional body memberships place you and your business at risk.</span></p>
                
                <p>FraudCheck is in the business of protecting its users against fraud by providing the information needed, educating them about ways to identify fraud and creating a greater awareness of the many types of and ways in which identity fraud is perpetrated. FraudCheck offers a comprehensive range of products that will uncover possible fraudsters quickly with accurate and easy to understand verification data.</p>

                <a href="register"><input type="button" class="btn btn-primary" value="CLICK HERE TO GET STARTED" /></a>
                <p>&nbsp;</p>
                <h2 class="green-heading">Enterprise Solutions</h2>
                <p>FraudCheck has a powerful backend capable of being utilised for a range of enterprise solutions. If you're looking to do a large volume of checks, please contact us today to enquire about how we can develop a solution that suits your needs.</p>
                <p>Examples of Enterprise Solutions:</p>
                <ul>
                	<li><strong>Application Programming Interfaces (API)Integration</strong> - Our API Integration process allows you to integrate the FraudCheck system into your enterprise systems. API integration enhances automation, reduces data inputting time, improves data accuracy, and allows you to tie your business processes together with the FraudCheck verification processes seamlessly and efficiently.</li>
                
                	<li><strong>Customised Scorecard & Reporting</strong> - The FraudCheck system provides real-time results delivered online in the format of our unique 360 degree scorecard. This score card based on YOUR business rules ensures objective decision making appropriate for your unique circumstances and eliminates hours of sifting through verification reports.</li>
                
                	<li><strong>White-labelled Solutions</strong> - FraudCheck offers white-label solutions for vendors and resellers who wish to offer verification services as part of their suit of offerings. </li>
                
                	<li><strong>Volume Discounts</strong> - Our unique menu pricing structure makes our service affordable and easy to access. We offer bundle pricing for regular users and large enterprises that require multiple checks.</li>
                
                	<li><strong>Service Level Agreements</strong> - For added security and because FraudCheck is confident about the quality of our reports and delivery times we enter into Service Level Agreements with our clients who have particular service delivery needs. </li>
				</ul>
                <a href="contact"><input type="button" class="btn btn-primary" value="CLICK HERE TO ENQUIRE" /></a>
            </div>
        </div>
    </div>

	<div class="space"></div>
	
   <a href="#0" class="cd-top">Top</a>
