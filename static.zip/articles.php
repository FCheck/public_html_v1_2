
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    Thought Leadership
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
    
    <div class="container">
    	<div class="page-header">
    	<h2 class="green-heading"><strong>Pre Employment Screening is vital to the Employment Process</strong></h2>
        <p>South African employers now have to change their modis operandi when making employment and hiring decisions. 
Recently we have seen many senior high profile leaders in both corporate and government entities being caught out for lying on their CVs and job applications.  Jeff Miller the acting CEO of Fraud Check estimates...</p>
		<p><input type="button" onclick="document.location.href='articles/pre-employment-screening-vital-to-employment'" class="btn btn-success" value="Read More" /></p>   
    </div>
    
    <div class="page-header">
    	<h2 class="green-heading"><strong>Drivers Licenses for Sale</strong></h2>
        <p>Where did you get your drivers licence is an extremely common question asked of South African drivers. Yes, believe it or not, fraudulent drivers licenses are a common phenomenon in our country. When it comes to employing drivers, companies need to be extra vigilant...</p>
		<p><input type="button" onclick="document.location.href='articles/drivers-license-for-sale'" class="btn btn-success" value="Read More" /></p>   
    </div>
    
    <div class="page-header">
    	<h2 class="green-heading"><strong>White Collar Crime in South Africa has Gone Wild</strong></h2>
        <p>White collar crime in South Africa has gone wild. Jeff miller acting CEO of Fraud check says it is vital for companies to conduct pre-employment screening of applicants before appointing them. Has the applicant got a valid ID number...</p>
		<p><input type="button" onclick="document.location.href='articles/white-collar-crime-south-africa'" class="btn btn-success" value="Read More" /></p>   
    </div>
    
 	<div class="space"></div>
    </div>
    
   <a href="#0" class="cd-top">Top</a>
