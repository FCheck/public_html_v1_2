
		<script>
			$("document").ready(function() {
				$(".scroll").click(function(event) {
					event.preventDefault();
					$('html,body').animate({
						scrollTop: $(this.hash).offset().top
					}, 500);
				});

				$("#back-top").hide();

				$(function() {
					$(window).scroll(function() {
						if ($(this).scrollTop() > 255) {
							$('#back-top').fadeIn();
						} else {
							$('#back-top').fadeOut();
						}
					});

					$('#back-top a').click(function() {
						$('body,html').animate({
							scrollTop: 0
						}, 800);
						return false;
					});
				});
			});
		</script>


<!-- Footer
    ================================================== -->
    <footer class="footer">
     <div class="container">
     	<div class="row">
        	<div class="col-sm-2">
            <h6>For You</h6>
            <ul class="list-unstyled">
            	<li><a href="for-you#getownscore">Get my Own Credit Score</a></li>
                <li><a href="for-you#check">Check Someone</a></li>
                <li><a href="register">Get Started</a></li>
                
            </ul>
            </div>
            <div class="col-sm-2">
            <h6>For Your Business</h6>
            <ul class="list-unstyled">
            	<li><a href="business">Our Services</a></li>
                <li><a href="register">Get Started</a></li>                
            </ul>
            </div>
        	<div class="col-sm-2">
            <h6>Services</h6>
            <ul class="list-unstyled">
            	<li><a href="services/id-check">ID Check</a></li>
                <li><a href="services/credit-check">Credit Check</a></li>
                <li><a href="services/criminal-check">Criminal Check</a></li>
                <li><a href="services/drivers-license-check">Drivers License Check</a></li>
                <li><a href="services/matric-verification">Matric Verification</a></li>
                <li><a href="services/tertiary-verification">Tertiary Education Verification</a></li>
                <li><a href="services/association-check">Association Check</a></li>
                <li><a href="services/bank-account-verification">Bank Account Verification</a></li>
                <!--<li><a href="services/bulk-data-purification">Bulk Data Purification</a></li>-->
                <li><a href="services/deeds">Deeds</a></li>
            </ul>
            </div>
            <div class="col-sm-2">
            <h6>About FraudCheck</h6>
            <ul class="list-unstyled">
            	<li><a href="what-we-do">What We Do</a></li>
                <li><a href="scorecard">Score Card</a></li>
                <li><a href="360-report">360 Report</a></li>
            	<li><a href="contact">Contact Us</a></li>
                <li><a href="faq">FAQ's</a></li>
                <li><a href="disagree">Disputes</a></li>
                <li><a href="purchase-credits">Purchase Credits</a></li>
            </ul>
            </div>
            <div class="col-sm-3">
            <a target="blank" href="https://twitter.com/FraudCheckSA"><img alt="Follow us on Twitter" src="images/iconbot1.png"></a><a target="blank" href="http://www.facebook.com/FraudCheckSA"><img alt="Follow us on Facebook" src="images/iconbot2.png"></a><a href="skype:fraudcheck?chat" name="skype" id="skype"><img alt="Skype us" src="images/iconbot4.png"></a>
                    <div class="whitehead20px">Email Support</div>
                        <div id="bottomnav2"><a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>
                        </div>
            </div>
        </div>
        <div class="row space text-center">
        &copy; Copyright Placis (Pty) Ltd - 2015 - All rights reserved. <a href="ts-and-cs">Terms and Conditions</a>
        </div>
        <div class="row space text-center">
        <img src="img/creditcards.png" height="50" />
        </div>
     </div>
    
    </footer>
    <script type="text/javascript">

                var trackcmp_email = '';

                var trackcmp = document.createElement("script");

                trackcmp.async = true;

                trackcmp.type = 'text/javascript';

                trackcmp.src = '//trackcmp.net/visit?actid=648954545&e='+encodeURIComponent(trackcmp_email)+'&r='+encodeURIComponent(document.referrer)+'&u='+encodeURIComponent(window.location.href);

                var trackcmp_s = document.getElementsByTagName("script");

                if (trackcmp_s.length) {

                                trackcmp_s[0].parentNode.appendChild(trackcmp);

                } else {

                                var trackcmp_h = document.getElementsByTagName("head");

                                trackcmp_h.length && trackcmp_h[0].appendChild(trackcmp);

                }

</script>

<!-- begin olark code -->
<script data-cfasync="false" type='text/javascript'>/*<![CDATA[*/window.olark||(function(c){var f=window,d=document,l=f.location.protocol=="https:"?"https:":"http:",z=c.name,r="load";var nt=function(){
f[z]=function(){
(a.s=a.s||[]).push(arguments)};var a=f[z]._={
},q=c.methods.length;while(q--){(function(n){f[z][n]=function(){
f[z]("call",n,arguments)}})(c.methods[q])}a.l=c.loader;a.i=nt;a.p={
0:+new Date};a.P=function(u){
a.p[u]=new Date-a.p[0]};function s(){
a.P(r);f[z](r)}f.addEventListener?f.addEventListener(r,s,false):f.attachEvent("on"+r,s);var ld=function(){function p(hd){
hd="head";return["<",hd,"></",hd,"><",i,' onl' + 'oad="var d=',g,";d.getElementsByTagName('head')[0].",j,"(d.",h,"('script')).",k,"='",l,"//",a.l,"'",'"',"></",i,">"].join("")}var i="body",m=d[i];if(!m){
return setTimeout(ld,100)}a.P(1);var j="appendChild",h="createElement",k="src",n=d[h]("div"),v=n[j](d[h](z)),b=d[h]("iframe"),g="document",e="domain",o;n.style.display="none";m.insertBefore(n,m.firstChild).id=z;b.frameBorder="0";b.id=z+"-loader";if(/MSIE[ ]+6/.test(navigator.userAgent)){
b.src="javascript:false"}b.allowTransparency="true";v[j](b);try{
b.contentWindow[g].open()}catch(w){
c[e]=d[e];o="javascript:var d="+g+".open();d.domain='"+d.domain+"';";b[k]=o+"void(0);"}try{
var t=b.contentWindow[g];t.write(p());t.close()}catch(x){
b[k]=o+'d.write("'+p().replace(/"/g,String.fromCharCode(92)+'"')+'");d.close();'}a.P(2)};ld()};nt()})({
loader: "static.olark.com/jsclient/loader0.js",name:"olark",methods:["configure","extend","declare","identify"]});
/* custom configuration goes here (www.olark.com/documentation) */
olark.identify('9311-741-10-6691');/*]]>*/</script><noscript><a href="https://www.olark.com/site/9311-741-10-6691/contact" title="Contact us" target="_blank">Questions? Feedback?</a> powered by <a href="http://www.olark.com?welcome" title="Olark live chat software">Olark live chat software</a></noscript>
<!-- end olark code -->
</body>
</html>