
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    Special Offer
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
<div class="container">
<?php
if (isset ($_POST  ['promo']))
{
	$code = $_POST  ['promo'];
	switch ($code)
	{
		case 'FRI45':
			//give 1 free credit
			//first log user in
			$GLOBALS ['user'] = new User (-1);
			$GLOBALS ['user']->email = $_POST ['email'];
			$GLOBALS ['user']->get_user_by_email ();
			$_SESSION ['login'] = true;
			$_SESSION ['user_id'] = $GLOBALS ['user']->get_user_id();
			
			$transactionId = $GLOBALS ['user']->create_purchase_reference();
			$check = $GLOBALS ['user']->confirm_transaction ($transactionId, 1, 0, "Coupon Redeemed - FRI45", 2);//status 2 = approved
			$output = "You have redeemed your 1 Free Credit. This can be used to run an ID check on Fraudcheck, please <a href='check-someone'>click here</a> to run your free ID check now!";
		break;
		case 'FR896':
			//give 10 free credit
			//first log user in
			
			$transactionId = $GLOBALS ['user']->create_purchase_reference();
			$check = $GLOBALS ['user']->confirm_transaction ($transactionId, 1, 0, "Coupon Redeemed - FRI45", 2);//status 2 = approved
			$output = "You have redeemed your 10 Free Credits. <a href='check-someone'>Click here</a> to run your free checks now!";
		break;
	}
	?>
    <div class="page-header">
    	<h2 class="green-heading"><strong>Whoop Whoop!</strong></h2> 
        <p><?php echo $output; ?></p>   
    </div>
    <?php
}
else
{
?>
	<div class="page-header">
    	<h2 class="green-heading"><strong>Claim your special offer</strong></h2> 
        <p>Congratulations, you made the cut! The fact that you're seeing this page means that we've extended a special offer to you. Enter your unique code below and claim your offer:</p>   
    </div>
    
 	
    <form method="post" action="coupon-process">
    <input type="hidden" name="email" value="<?php echo $q[1]; ?>" />
    
        <div class="form-group">
        <div class="row">
       		<label for="promo" class="col-sm-2 control-label">Promotional Code:</label>
       	    <div class="col-sm-10" style="margin-bottom:10px">
           		<input type="text" class="form-control" id="OTP" placeholder="Promotional Code" name="promo" style="max-width:400px">
           	</div>
       	</div>
        </div>
        
        
        <div class="space"></div>
        <div class="form-group">
     		<div align="center" style="margin-top:10px">
       			<button class="btn-primary btn-lg">Give me Free Stuff</button>
            </div>
       	</div>
	</form>
<?php
}
?>
    <script type="text/javascript">
    var __ss_noform = __ss_noform || [];
    __ss_noform.push(['baseURI', 'https://app-9IDAHGXA.sharpspring.com/webforms/receivePostback/MzMwNbQwBQA/']);
    __ss_noform.push(['endpoint', '2ff40994-ddee-4ed6-9e5f-e670f5a44466']);
</script>
<script type="text/javascript" src="https://koi-9IDAHGXA.sharpspring.com/client/noform.js?ver=1.0" ></script>

</div>
<div class="space"></div>
	
 <a href="#0" class="cd-top">Top</a>
