
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    I Disagree with the Outcome
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
    
    <div class="container">
        <div class="page-header green-heading">
          <strong>Disputing a Recommendation</strong>
        </div>
    
    	<div class="row space">
            <div class="col-md-9">
            If you disagree with the fraud screening recommendation that you received for the ID verification check or full person background check, you are able to dispute the result at any time.
<br>
<br>
Simply register as a FraudCheck user to check which person has checked you. Raising a dispute is as simple as clicking a Dispute button for the ID verification check or full person background check when you disagree with the fraud screening recommendation that FraudCheck made.

            </div>
            <div class="col-md-3"><img src="images/img/fraud-screening-dispute.png"/></div>
        </div>
    </div>
    
    <div class="container">
        <div class="page-header green-heading">
          <strong>What do we do to Resolve it?</strong>
        </div>
    
    	<div class="row space">
            <div class="col-md-12">
             When you view a FraudCheck fraud screening recommendation and its details, you will be able to dispute the outcome of the ID verification check or full person background check by clicking the Dispute button that is available on the fraud screening recommendation page. You will be prompted to select one of the following options as a reason for your dispute: Disagree with Recommendation, I was defrauded, Suspicious behavior after some time, Person is deceased, or Other. When you submit the dispute, a ticket is logged with the FraudCheck Support Team who will then investigate your case and respond within 24 hours from the time that you sent it. Resolution of a dispute may take longer, depending on the nature of your dispute, but we will assist you every step of the way!
            </div>
        </div>
    </div>

	<div class="space">
    <a href="register"><button class="btn-primary btn-lg center-block">Sign Up For Free</button></a>
	</div>
    
    
   <a href="#0" class="cd-top">Top</a>
