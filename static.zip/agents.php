
<!-- Header Image
    ================================================== -->
<div class="jumbotron subheadbanner">
  <div class="container content-header">
    <h1>Fraudcheck Accredited Agents</h1>
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->

    <div class="container space">
    	<div class="row">
            <div class="col-md-12">
            	<h2 class="green-heading">Find your nearest agent</h2>

                <p><span class="service-question">Fraudcheck has agencies in Provinces Nationwide that processes criminal checks on our behalf:</span></p>

                <h3 class="green-heading">HEAD-OFFICE:</h3>

                <p>FRAUDCHECK <br />
                     Pinmall Office Park<br />
                     Katherine Drive / Sandton<br />
                     2119<br /><br />
                     Tel: +272625252
                </p>
                <br />
                <h3 class="green-heading">Customer Support:</h3>

                <p>Customer Support <br />
                     support@fraudcheck.co.za<br />
                     www.fraudcheck.co.za/support<br />
                    <br /><br />
                     Tel: +272625252
                </p>

                <br /><br /><br />
                <h2 class="green-heading">Become a Fraudcheck accredited agent</h2>
                <p>Contact us at 011 262 5252 or e-mail us at support@fraudcheck.co.za to become an Agency to process criminal checks on Fraudcheck’s behalf.</p>
                <a href="contact"><input type="button" class="btn btn-primary" value="CLICK HERE TO ENQUIRE" /></a>
            </div>
        </div>
    </div>

	<div class="space"></div>

   <a href="#0" class="cd-top">Top</a>
