
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(/images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    Fraudcheck for You
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
<div class="container">
	<div class="page-header">
    	<h2 class="green-heading"><strong>Getting Started</strong></h2>    
    </div>

    <div style="margin-top:7px; margin-bottom:7px; text-align:justify;">In order to start using the FraudCheck online portal all you have to do is follow the simple steps below:</div>
    <div class="container space">
    	<div class="row">
        	<div class="col-md-1 text-center">
            <img src="/images/img/bullet-1.png">
            </div>
            <div class="col-md-11" style="margin-top:10px">
            Fully complete the online registration form below and then click Register
            </div>
        </div>
    </div>
    
    
    <div class="container space">
    	<div class="row">
        	<div class="col-md-1 text-center">
            <img src="/images/img/bullet-2.png">
            </div>
            <div class="col-md-11" style="margin-top:10px">
            You will receive an email confirmation from FraudCheck with a security link to confirm your registration, click on "Activate My Account"
            </div>
        </div>
    </div>
    
    <div class="container space">
    	<div class="row">
        	<div class="col-md-1 text-center">
            <img src="/images/img/bullet-3.png">
            </div>
            <div class="col-md-11" style="margin-top:10px">
            You will receive a one time pin by way of SMS (this may take a few minutes). Enter this pin on the activation page and create your password.
            </div>
        </div>
    </div>
    
    <div class="container space">
    	<div class="row">
        	<div class="col-md-1 text-center">
            <img src="/images/img/bullet-4.png">
            </div>
            <div class="col-md-11" style="margin-top:10px">
            You will automatically be logged in upon successful registration.
            </div>
        </div>
    </div>
    
    <div class="container space">
    	<div class="row">
        	<div class="col-md-1 text-center">
            <img src="/images/img/bullet-5.png">
            </div>
            <div class="col-md-11" style="margin-top:10px">
            You may now <a href="purchase-credits">purchase credits</a> and begin using Fraud Check!
          </div>
        </div>
    </div>

    <div class="space"></div>
    <div id="collectdata">
    <form method="post" action="consumer-register" onsubmit="return reg_run_check()">
        <div class="page-header">
        	<h2 class="green-heading"><strong>Register to Use FraudCheck</strong></h2>
        </div>
       	<div class="form-group">
       		<label for="firstName" class="col-sm-2 control-label">First Name</label>
       	    <div class="col-sm-10" style="margin-bottom:10px">
           		<input type="text" class="form-control" id="firstName" placeholder="First Name" name="firstName" style="width:400px">
           	</div>
       	</div>
       	<div class="form-group">
       		<label for="surname" class="col-sm-2 control-label">Surname</label>
       	    <div class="col-sm-10" style="margin-bottom:10px">
       	    	<input type="text" class="form-control" id="surname" placeholder="Surname" name="surname" style="width:400px">
       	    </div>
       	</div>
       	<div class="form-group">
       		<label for="idNumber" class="col-sm-2 control-label">ID Number</label>
       	    <div class="col-sm-10" style="margin-bottom:10px">
       	    	<input type="text" class="form-control" id="idNumber" placeholder="ID Number" name="idNumber" style="width:400px">
       	    </div>
       	</div>
       	<div class="form-group">
       		<label for="emailAddress" class="col-sm-2 control-label">Email Address</label>
           	<div class="col-sm-10" style="margin-bottom:10px">
           		<input type="text" class="form-control" id="emailAddress" placeholder="Email Address" name="emailAddress" style="width:400px">
           	</div>
       	</div>
       	<div class="form-group">
       		<label for="userPhones" class="col-sm-2 control-label">Cellphone Number</label>
       	    <div class="col-sm-10" style="margin-bottom:10px">
       	    	<input type="text" class="form-control" id="userPhones" placeholder="Cellphone Number" name="tel" style="width:400px">
       	    </div>
       	</div>
       	<div class="form-group">
       		<label for="maritalStatus" class="col-sm-2 control-label">Marital Status</label>
       	    <div class="col-sm-10" style="margin-bottom:10px">
       	    	<select class="form-control" id="maritalStatus" style="width:400px" name="maritalStatus">
       	        	<option value="SINGLE">Single</option>
       	            <option value="MARRIED">Married</option>
       	            <option value="DIVORCED_WIDOWED">Divorced / Widowed</option>
       	        </select>
       	    </div>
       	</div>
       	<div class="form-group">
       		<label for="inputFirstName" class="col-sm-2 control-label">Physical Address</label>
       	    <div class="col-sm-5" style="margin-bottom:10px">
       	    	<input type="text" class="form-control" id="buildingName"  maxlength="20" name="buildingName" placeholder="Building / Complex Name" style="width:400px">
       	    </div>
       	    <div class="col-sm-5" style="margin-bottom:10px">
       	        <input type="text" class="form-control" id="buildingNumber" name="buildingNumber" placeholder="Building / Complex Number" style="width:400px">
       	    </div>
       	    <div class="col-sm-2"></div>
       	    <div class="col-sm-5" style="margin-bottom:10px">
       	        <input type="text" class="form-control" id="streetName" name="streetName" placeholder="Street Name" style="width:400px">
       	    </div>
       	    <div class="col-sm-5" style="margin-bottom:10px">
       	        <input type="text" class="form-control" id="suburb" name="suburb" placeholder="Suburb" style="width:400px">
       	    </div>
       	    <div class="col-sm-2"></div>
       	    <div class="col-sm-5" style="margin-bottom:10px">
       	        <input type="text" class="form-control" id="city" name="city" placeholder="City" style="width:400px">
       	    </div>
       	    <div class="col-sm-5" style="margin-bottom:10px">
       	        <select class="form-control" id="stateProvince" name="province" style="width:400px">
       	        	<option value="Gauteng">Gauteng</option>
       	            <option value="Western Cape">Western Cape</option>
                    <option value="Eastern Cape">Eastern Cape</option>
                    <option value="Northern Cape">Northern Cape</option>
                    <option value="Mpumalanga">Mpumalanga</option>
                    <option value="Kwazulu Natal">Kwazulu Natal</option>
                    <option value="North West">North West</option>
                    <option value="Limpopo">Limpopo</option>
                    <option value="Free State">Free State</option>
           		</select>
           	</div>
            <div class="col-sm-2"></div>
            <div class="col-sm-10" style="margin-bottom:10px">
           	    <input type="text" class="form-control" id="postalCode" name="postalCode" placeholder="Postal Code" style="width:400px">
           	</div>
           	<div class="col-sm-2"></div>
            <div class="col-sm-5" style="margin-bottom:10px">
       	        <select class="form-control" id="addressType" name="addressType" style="width:400px">
       	        	<option value="HOUSE">House</option>
       	            <option value="COMPLEX">Complex</option>
                    <option value="OFFICE">Office</option>
           		</select>
           	</div>
			<div class="col-sm-5" style="margin-bottom:10px">
            	<select class="form-control" id="propertyType" style="width:400px" name="propertyType">
                	<option value="OWNED">I own this property</option>
                    <option value="NOT_OWNED">I do not own this property</option>
                </select>
            </div>
           	
       	</div>
   
     	<div class="form-group">
     		<div align="center" style="margin-top:10px">
       			<button class="btn-primary btn-lg">Register</button>
            </div>
       	</div>
	</form>
</div>
</div>
 <div class="space"></div>
 <div id="runchecks" style="display:none;">
 <div align="center" class="container">
    <div class="page-header green-heading">
                Please wait while we process your registration.
             </div>
             <div class="space"></div>
    	<img src="/images/img/runcheck.gif" /><br /><br />
		
    </div>

	<div class="space"></div>
    <div class="space"></div>
    <div class="space"></div>
    <div class="space"></div>
    <div class="space"></div>
    <div class="space"></div>
	<div class="space"></div>
    </div>
<div class="space"></div>
	
 <a href="#0" class="cd-top">Top</a>
