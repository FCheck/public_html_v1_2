<?php
include ("functions/functions.php");
session_start ();
if (isset ($_SESSION ['login']))
{
	//logged in
	$GLOBALS ['user'] = new User (0);
	if (isset ($_GET ['query']))
	{
		$q = explode ('/',strtolower ($_GET ['query']));
		$command = $q[0];//first forward slash in url (primary command)
		if (strcmp ($command, "run-check") == 0)
		{
			//head ("runcheck", "Running Check(s) - Please Wait");
			//include ("templates/runcheck.php");
			$_POST ['userId'] = $GLOBALS ['user']->get_user_id ();
			$_POST ['accountId'] = $GLOBALS ['user']->accountId;
			if (isset ($_POST ['consent']))
			{
				$consent = $_POST ['consent'];
			}
			else
			{
				$consent = $GLOBALS ['user']->get_mandatory_consent ();
			}
			if (strcmp ($consent, "1") == 0)
			{
				$check = new ConsentCheck ($_POST);
			}
			else
			{
				$check = new Check ($_POST);
				$check->submitCheck ();
			}
		}		
		else if (strcmp ($command, "transaction") == 0)
		{
			$url = urldecode ($_SERVER ['REQUEST_URI']);
			$urlparts =  explode ("?",$url);
			$getvarparts = explode ("&",$urlparts[1]);
			$getvars = array ();
			foreach ($getvarparts as $get)
			{
				$temp = explode ("=",$get);
				$getvars[$temp[0]] = $temp[1];
			}
			//print_r ($getvars);
			$testing = 1;
			$exclvat = $getvars ['p6']/1.14;
			$vat = $getvars ['p6'] - $exclvat;
			$credits = $exclvat/10;
			if (strcmp ($q[1], "approved") == 0)
			{
				//transaction approved
				if (strcmp ($getvars['p1'], 'F159') == 0 && (strcmp ($getvars['CardHolderIpAddr'],$_SERVER ['REMOTE_ADDR']) == 0) || $testing == 1)
				{
					//ip check confirmed
					
					$check = $GLOBALS ['user']->confirm_transaction ($getvars['p2'], $credits, $getvars['p6'], $getvars['p3'], 2);//status 2 = approved
					if ($check == true)
					{
						head ("transaction-approved", "Transaction Approved");
						include ("templates/transaction/approved.php");
					}
					else
					{
						head ("transaction-approved", "Error Occurred");
						include ("templates/transaction/error.php");
					}
				}
			}
			else
			{
				//transaction declined
				$check = $GLOBALS ['user']->confirm_transaction ($getvars['p2'], $credits, $getvars['p6'], $getvars['p3'], 3);//status 3 = declined
				head ("transaction-approved", "Transaction Unsuccessful");
				include ("templates/transaction/declined.php");
			}
		}
		else if (file_exists("templates/$command.php") || strcmp ($command, "index") == 0)
		{
			$t = str_replace ("-"," ", $command);
			$t = ucwords ($t);

			head ($command, $t);
			if (strcmp ($command, "index") == 0)
				include ("templates/overview.php");
			else
				include ("templates/$command.php");
		}
		else
			get_static_page ();
	}
	else
	{
		head ("Overview", "Overview");
		include ("templates/overview.php");
	}
}
else
{
	//not logged in
	if (isset ($_GET ['query']))
	{
		$q = explode ('/',strtolower ($_GET ['query']));
		$command = $q[0];//first forward slash in url (primary command)
		if (strcmp ($_GET ['query'], "consumer-register") == 0)
		{
			$register = new RegisterStep1 ($_POST);
			$response = $register->response;
			if (empty ($response))
			{
				$response = array ();
				$response ['message'] = "Temporary system error. Please try again later.";
				head ("confirm-email", "Registration Error");
				include ("static/activate/error.php");
			}
			else if (strcmp ($response ['status'], "SUCCESS") == 0)
			{
				head ("confirm-email", "Thank you for Registering");
				include ("static/activate/thanks.php");
			}
			else
			{
				head ("confirm-email", "Registration Error");
				include ("static/activate/error.php");
			}
		}
		else if (strcmp ($_GET ['query'], "business-register") == 0)
		{
			$register = new CompanyRegister ($_POST);
			$response = $register->response;
			if (empty ($response))
			{
				$response = array ();
				$response ['message'] = "Temporary system error. Please try again later.";
				head ("confirm-email", "Registration Error");
				include ("static/activate/error.php");
			}
			else if (strcmp ($response ['status'], "SUCCESS") == 0)
			{
				head ("confirm-email", "Thank you for Registering");
				include ("static/activate/thanks.php");
			}
			else
			{
				head ("confirm-email", "Registration Error");
				include ("static/activate/error.php");
			}
		}
		else if (strcmp ($command, "reset-password-thanks") == 0)
		{
			$url = "userdata/requestPasswordReset/".$_POST ['email'];
			$request = "";
			$api = new Api ();
			$return = $api->submit_api_request ($request, $url);
			head ("reset-password", "Reset Password");
			include ("static/reset-password-thanks.php");
		}
		else if (strcmp ($_GET ['query'], "consent-post-back") == 0)
		{
			$arr = array ();
			$arr ['apiId'] = $_POST ['api_id'];
			$arr ['from'] = $_POST ['from'];
			$arr ['text'] = $_POST ['text'];
			$arr ['moMsgId'] = $_POST ['moMsgId'];
			$arr ['to'] = $_POST ['to'];
			$request = json_encode ($arr);
			$url = "userdata/consent-post-back";
			$api = new Api ();
			$return = $api->submit_api_request ($request, $url, 1);
			//$file = fopen ("newfiletest2.txt","w");
			//fwrite ($file,"apiId = ".$arr ['apiId']."\nfrom = ".$arr['from']."\ntext = ".$arr['text']."\nmoMsgId = ".$arr ['moMsgId']."\nto = ".$arr ['to']);
			//fclose ($file);
			//echo $request;
		}
		else if (strcmp ($command, "regtest") == 0)
		{
			head ("confirm-email", "Email Address Confirmed");
			include ("static/activate/otp.php");
		}
		else if (strcmp ($command, "activate") == 0)
		{
			$data = array ();
			$data ['email'] = $q[1];
			$data ['authKey'] = $q[2];
			$request = json_encode ($data);
			$url = "userdata/verifyRegistrationEmail";
			$api = new Api ();
			$return = $api->submit_api_request ($request, $url, 1);
			//$return = 1;
			if ($return == 1)
			{
				//email address verified successfully
				head ("confirm-email", "Email Address Confirmed");
				include ("static/activate/otp.php");
			}
			else
			{
				//error
				head ("error", "Error");
				echo "Error: ".$return;
			}
		}
		else if (strcmp ($command, "activate-otp") == 0)
		{
			$data = array ();
			$data ['email'] = $_POST ['email'];
			$data ['authKey'] = $_POST ['OTP'];
			$request = json_encode ($data);
			$url = "userdata/verifyRegistrationOtp";
			$api = new Api ();
			$return = $api->submit_api_request ($request, $url, 1);
			//$return = 1;
			if ($return == 1)
			{
				//email address verified successfully
				$data = array ();
				$data2 ['email'] = $_POST ['email'];
				$_POST ['emailAddress'] = $_POST ['email'];
				$data2 ['password'] = $_POST ['password'];
				$request = json_encode ($data2);
				$url = "userdata/updateUserPassword";
				$return = $api->submit_api_request ($request, $url, 1);
				if ($return == 1)
				{
					$acc_type = $_POST ['acc_type'];
					if ($acc_type == 1)
					{
						$GLOBALS ['user'] = new User (-1);
						$GLOBALS ['user']->email = $_POST ['email'];
						$GLOBALS ['user']->set_password ($_POST ['password']);
						$GLOBALS ['user']->get_user_by_email ();
						$_SESSION ['login'] = true;
						$_SESSION ['user_id'] = $GLOBALS ['user']->get_user_id();
						if (!empty ($_POST ['promo']))
						{
							if (strcmp (strtolower ($_POST ['promo']), 'fr896') == 0)
							{
								$transactionId = $GLOBALS ['user']->create_purchase_reference();
								$check = $GLOBALS ['user']->confirm_transaction ($transactionId, 10, 0, "Coupon Redeemed - FR896", 2);//status 2 = approved
								head ("registration-email", "Registration Confirmed");
								include ("templates/check-someone.php");
							}
							else
							{
								head ("registration-email", "Registration Confirmed");
								include ("templates/buy-credits.php");
							}
						}
						else
						{
							head ("registration-email", "Registration Confirmed");
							include ("templates/buy-credits.php");
						}
					}
					else
					{
						$register = new RegisterStep2Business ($_POST);
						$response = $register->response;
						if (empty ($response))
						{
							$response = array ();
							$response ['message'] = "Temporary system error. Please try again later.";
							head ("confirm-email", "Registration Error");
							include ("static/activate/error.php");
						}
						else if (strcmp ($response ['status'], "SUCCESS") == 0)
						{
							$GLOBALS ['user'] = new User (-1);
							$GLOBALS ['user']->email = $_POST ['email'];
							$GLOBALS ['user']->set_password ($_POST ['password']);
							$GLOBALS ['user']->get_user_by_email ();
							$_SESSION ['login'] = true;
							$_SESSION ['user_id'] = $GLOBALS ['user']->get_user_id();
							$GLOBALS ['justreg'] = 1;
							if (!empty ($_POST ['promo']))
							{
								if (strcmp (strtolower ($_POST ['promo']), 'fr896') == 0)
								{
									$transactionId = $GLOBALS ['user']->create_purchase_reference();
									$check = $GLOBALS ['user']->confirm_transaction ($transactionId, 10, 0, "Coupon Redeemed - FR896", 2);//status 2 = approved
									head ("registration-email", "Registration Confirmed");
									include ("templates/check-someone.php");
								}
								else
								{
									head ("registration-email", "Registration Confirmed");
									include ("templates/buy-credits.php");
								}
							}
							else
							{
								head ("registration-email", "Registration Confirmed");
								include ("templates/buy-credits.php");
							}
						}
						else
						{
							head ("confirm-email", "Registration Error");
							include ("static/activate/error.php");
						}
					}
				}
			}
			else
			{
				//error
				head ("error", "Error");
				echo "Error: ".$return;
			}
		}
		else if (strcmp ($command, "reset") == 0)
		{
			$data = array ();
			$data ['email'] = $q[1];
			$data ['authKey'] = $q[2];
			$request = json_encode ($data);
			$url = "userdata/verifyPasswordResetEmail";
			$api = new Api ();
			$return = $api->submit_api_request ($request, $url, 1);
			//$return = 1;
			if ($return == 1)
			{
				//email address verified successfully
				head ("confirm-email", "Email Address Confirmed");
				include ("static/reset/otp.php");
			}
			else
			{
				//error
				head ("error", "Error");
				echo "Error: ".$return;
			}
		}
		else if (strcmp ($command, "reset-otp") == 0)
		{
			$data = array ();
			$data ['email'] = $_POST ['email'];
			$data ['authKey'] = $_POST ['OTP'];
			$request = json_encode ($data);
			$url = "userdata/verifyPasswordResetOtp";
			$api = new Api ();
			$return = $api->submit_api_request ($request, $url, 1);
			//$return = 1;
			if ($return == 1)
			{
				//email address verified successfully
				$data = array ();
				$data2 ['email'] = $_POST ['email'];
				$data2 ['password'] = $_POST ['password'];
				$request = json_encode ($data2);
				$url = "userdata/updateUserPassword";
				$return = $api->submit_api_request ($request, $url, 1);
				head ("reset-email", "Registration Confirmed");
				include ("static/reset/confirmed.php");
			}
			else
			{
				//error
				head ("error", "Error");
				echo "Error: ".$return;
			}
		}
		else if (file_exists("templates/".$q[0].".php"))
		{
			//echo "location: login/".$_GET['query'];
			header ("location: http://".$_SERVER['HTTP_HOST']."/login/".$_GET['query']);
		}
		else
		{
			get_static_page ();
		}
	}
	else
	{
		head ("home", "Identity verification service | Fingerprinting background check");
		include ("static/home.php");
	}
}
include ("static/footer-static.php");

function get_static_page ()
{
	$q = explode ('/',strtolower ($_GET ['query']));
	$command = $q[0];//first forward slash in url (primary command)
	$title = "";
	foreach ($q as $t)
	{
		$t = str_replace ("-"," ", $t);
		$t = ucwords ($t);
		if (empty ($title))
			$title = $t;
		else
			$title .= " - ".$t;
	}
	if (strcmp ($title, "Home") == 0)
		$title = "Background and Pre-Employment Screening Services";
	if (!empty ($q[1]) && file_exists("static/$command"))
	{
		//go into folder
		head ($command, $title);
		include ("static/$command/".$q[1].".php");
	}
	else
	{
		head ($command, $title);
		if (strrpos ($command,".php") === false)
			include ("static/$command.php");
		else
			include ("static/$command");
	}
}
?>