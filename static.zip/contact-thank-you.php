
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
   Contact Us
   <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
    
    <div class="container">

    	<div class="row space">
            <div class="col-md-7">
            <?php
			 if (!empty ($_POST ['requestType']))
			 {
				 $api = new Api ();
				$url = "userdata/contact?firstName=".$_POST ['contactName']."&companyName=".$_POST ['companyName']."&emailAddress=".$_POST ['email']."&requestType=".$_POST ['requestType']."&subject=".$_POST ['subject']."&message=".$_POST ['message'];
				$variables ['test'] = "test";
				$request = json_encode ($variables);
				$return = $api->submit_api_request ($request, $url, 1);
				$response = json_decode ($return, true);
				//echo $return;
			 }
			?>
             <?php
			 if (!empty ($_POST ['field_49612801']))
			 {
				 $api = new Api ();
				$url = "userdata/contact?firstName=".urlencode ($_POST ['field_49612801'])."&companyName=".urlencode ($_POST ['field_49615873'])."&emailAddress=".urlencode ($_POST ['field_49614849'])."&requestType=".urlencode ($_POST ['field_54104065'])."&subject=".urlencode ($_POST ['field_54105089'])."&message=".urlencode ($_POST ['field_54106113']);
				$variables ['test'] = "test";
				$request = json_encode ($variables);
				$return = $api->submit_api_request ($request, $url, 1);
				$response = json_decode ($return, true);
				//echo $return;
			 }
			?>
             <div class="page-header green-heading">
                <strong>Thank you</strong>
             </div>
             
             <div class="space"></div>
             
          <p>Thank you for submitting your details, we will get back to you shortly.</p>

          </div>
          <div class="col-md-1"></div>
          <div class="col-md-3">
            <br>
			<br>
          	<h4>Support Desk</h4> 

            <strong>Call:</strong> 011 262 5252
            <br>
            <strong>Email:</strong> <a href="mailto:support@fraudcheck.co.za">support@fraudcheck.co.za</a>
            <br>
            <strong>Verification/Documents Email:</strong> <a href="mailto:verify@fraudcheck.co.za">verify@fraudcheck.co.za</a>
          </div>
          
        </div>
    </div>

	<div class="space"></div>
    
    
   <a href="#0" class="cd-top">Top</a>
