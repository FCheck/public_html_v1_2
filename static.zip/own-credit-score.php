
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    FraudCheck For You
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
    
    <div class="container">  
    	<div class="row space">
            <div class="col-md-12">
            <div class="page-header green-heading">
          <strong>Comprehensive, Easy to Read Reporting</strong>
        </div>
            FraudCheck has implemented real-time 360 degree reporting capabilities. This allows multiple users to view at anytime the status of their enquiries. These enquiries can be searched by any of the following:<br /><br />
			<ul>
            	<li>ID number</li>
				<li>Type of check</li>
				<li>Date</li>
            </ul>

FraudCheck has the ability to customise reporting for companies. Please feel free to contact us in this regard. This reporting tool allows for audit trail and time stamps. It also allows for historical checks to be viewed at anytime. 
<div class="space"></div>
			 <div class="page-header green-heading">
          <strong>Sample Report</strong>
        </div>
        <img src="images/360-report.png" />
            </div>
        </div>
    </div>
    
    
    
    
   <a href="#0" class="cd-top">Top</a>
