
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    Resources
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
    
    <div class="container">
    	<div class="page-header">
        <h2 class="green-heading"><strong>Download Free E-Books</strong></h2>
        </div><br /><br />
        <div style="float:left; padding-right:55px;">
        	<a href="resources/where-did-all-the-people-go" style="display:block; height:270px"><img src="images/where-did-all-the-people-go-thumb.jpg" alt="Where did all the people go?" /></a><br /><br />
			<p><input type="button" onclick="document.location.href='resources/where-did-all-the-people-go'" class="btn btn-success" value="Where did all the people go?" /></p>
        </div> 
        <div style="float:left; padding-right:55px;">
        	<a href="resources/ultimate-guide-to-hiring" style="display:block; height:270px"><img src="images/ultimate-guide-to-hiring-thumb.jpg" alt="The Ultimate Guide to Hiring" /></a><br /><br />
			<p><input type="button" onclick="document.location.href='resources/ultimate-guide-to-hiring'" class="btn btn-success" value="The Ultimate Guide to Hiring" /></p>
        </div> 
        <br /><br />
    </div>
    
    
 	
    
    
   <a href="#0" class="cd-top">Top</a>
