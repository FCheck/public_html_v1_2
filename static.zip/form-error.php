
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    Error
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
    
    <div class="container">
    	<div class="page-header">
    	<h2 class="green-heading">Error Occurred</h2>
        <div class="space"></div>
        An error occurred while processing your request, please go back and try again
        </div>
    
 	<div class="space"></div>
    </div>
    
   <a href="#0" class="cd-top">Top</a>
