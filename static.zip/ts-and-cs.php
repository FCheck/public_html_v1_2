
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
   Terms and Conditions
   <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
    
    <div class="container">
    
    	<div class="row space">
          <div class="col-md-12 text-center">
          	<div class="page-header green-heading">
                  <strong>FraudCheck&reg;</strong>
                </div>
             <span class="terms-subtitle">TERMS AND CONDITIONS</span><br> *Individual
				words appearing in bold text are defined below
          </div>
        </div>
        
        <div class="row space">
          <div class="col-md-12">
             	
                <div class="page-header green-heading">
                  <strong>SECTION A</strong>: TO BE ACCEPTED BY THE CLIENT
                </div>
				<br>

			<strong>ACCEPTANCE OF TERMS AND CONDITIONS</strong><br> BY
				ACCESSING THIS WEBSITE AND/OR USING ANY OF THE INFORMATION, <strong>DATA</strong>,
				OR SERVICES HEREON YOU ARE DEEMED TO HAVE READ EXPRESSLY CONSENTED
				TO AND ARE BOUND BY THE TERMS AND CONDITIONS OF USE. The terms and
				conditions shall be applicable and binding upon every transaction.
                <br>
				<br>
                
                <div class="page-header green-heading">
                  <strong>DISCLAIMER</strong>
                </div>
				<br>
                
                The <strong>Data</strong> supplied to the <strong>Client</strong>, is the result of
				information supplied from various data bases accumulated by <strong>Vendors</strong>
				who collect and monitor particular consumer profiles. The accuracy
				of <strong>Data</strong> supplied by this website is entirely
				dependent upon the information supplied by the third party <strong>Vendors</strong>.
				THE <strong>SUPPLIER</strong> DOES THEREFORE NOT WARRANT THE
				ACCURACY OF THE <strong>DATA</strong>. THE <strong>SUPPLIER</strong>
				CANNOT BE HELD LIABLE WHETHER IN CONTRACT, DELICT OR BREACH OF
				WARRANTY FOR ANY LOSS OR DAMAGES, HOWSOEVER ARISING, THROUGH OR OUT
				OF THE <strong>CLIENT</strong> (OR ANY OTHER THIRD PARTY) HAVING
				PLACED RELIANCE UPON THE <strong>DATA</strong> PROVIDED BY THE <strong>SUPPLIER</strong>.
				THE <strong>SUPPLIER</strong> ACCORDINGLY DOES NOT ACCEPT ANY
				LIABILITY FOR ANY INACCURACIES, OMISSIONS OR MISTAKES IN THE
				INFORMATION PROVIDED BY VENDORS OR OCCURRING IN THE DATA.
                <br> <br>
                
                <div class="page-header green-heading">
                  <strong>WARRANTY</strong>
                </div>
				<br>
                
				The <strong>Client</strong>
				warrants and undertakes that he/she will submit the actual cell
				phone number of the <strong>Subject</strong> for the purpose of
				obtaining an "opt-in" (granting of consent) from the <strong>Subject</strong>.
				It is the sole responsibility of the <strong>Client</strong> to
				ensure the accuracy or reliability of the <strong>Subject's</strong>
				cell phone number for that purpose. The <strong>Client</strong>
				accordingly indemnifies and holds the <strong>Supplier</strong>
				harmless against any claim, loss or damage which may arise through
				or out of submitting the incorrect cell phone number of the <strong>Subject</strong>.
				The <strong>Client</strong> further grants consent to and authorises
				the <strong>Supplier</strong> to perform any such verification that
				it may deem necessary, including accessing the personal information
				of the <strong>Client</strong>, for the purpose of establishing
				whether the <strong>Client</strong> has in fact complied with the
				terms contained herein. The <strong>Client</strong> warrants that
				they have a <span style="font-style: italic;">bona fide</span>
				business reason to access the Data on the <strong>Subject</strong>.
				The <strong>Client</strong> further warrants that they shall not
				disseminate the <strong>Data</strong> to any party other than the <strong>Subject</strong>.
				The <strong>Client</strong> understands that their service will be
				terminated in the event that they contravene the aforementioned
				conditions. The <strong>Client</strong> understands and hereby
				provides express consent for the <strong>Supplier</strong> to
				perform an identity verification on the <strong>Client</strong> upon
				initiation of the services. The <strong>Client</strong> further
				understands that the <strong>Supplier</strong> shall not provide any
				Data to any <strong>Client</strong> whose identity has not been
				authenticated by the <strong>Supplier</strong>. The <strong>Supplier's</strong>
				right to reject any <strong>Client's</strong> application for <strong>Data</strong>
				on any <strong>Subject</strong> is fully reserved in all
				circumstances, particularly if the <strong>Client's</strong>
				identity has not be verified or if the <strong>Supplier</strong> is
				of the opinion that the application for <strong>Data</strong> is not
				motivated by a <span style="font-style: italic;">bona fide</span>
				business reasons or interest. The <strong>Client</strong> expressly
				consents to any information gained from the identification
				verification being shared between the contracted Vendors. It is the
				responsibility of the <strong>Client</strong> to inform the <strong>Subject</strong>
				of the fact the <strong>Client</strong> will be utilising the
				services of the <strong>Supplier</strong> to perform a consumer
				profile assessment on the <strong>Subject</strong>. It is the duty
				of the <strong>Client</strong> to inform the <strong>Subject</strong>
				of the specific purpose or reason for the assessment to be performed
				on the <strong>Subject</strong>; and the <strong>Client</strong>
				shall inform the <strong>Subject</strong> of the SMS which shall be
				sent by the <strong>Supplier</strong> to the <strong>Subject</strong>
				to gain the "opt-in" of the <strong>Subject</strong>.
			
				<br><br>
                
                <div class="page-header green-heading">
                  <strong>SECTION B</strong>: TO BE READ BY RECIPIENT OF SMS (THE SUBJECT)
                </div>
				<br>
			
			
				The person who is the <strong>Subject</strong> of the query made by
				the <strong>Client</strong> will receive an SMS requiring them to
				"opt-in". By "opting-in" per return SMS, the <strong>Subject</strong>
				is deemed to have <strong>provided their express consent</strong> to
				their personal information being passed on and utilised for the
				purpose of generating the <strong>Data</strong>, as well as to this
				<strong>Data</strong> being provided to the <strong>Client</strong>.
				BY OPTING IN, THE SUBJECT IS BOUND BY THE PROVISION CONTAIN HEREIN.
				THE SUBJECT FURTHER ACCEPTS THAT THE <strong>SUPPLIER</strong>
				CANNOT BE HELD LIABLE FOR ANY LOSS OR DAMAGES (WHETHER DIRECT OR
				CONSEQUENTIAL), HOWSOEVER ARISING, THROUGH OR OUT OF ANY INACCURACY
				IN THE INFORMATION OR RESULTANT <strong>DATA</strong>. THE <strong>SUPPLIER</strong>
				ACCORDINGLY DOES NOT ACCEPT ANY LIABILITY FOR ANY INACCURACIES,
				OMISSIONS OR MISTAKES IN THE INFORMATION PROVIDED BY <strong>VENDORS</strong>
				OR OCCURRING IN THE <strong>DATA</strong>.
			
				<br><br>
			
				<a name="EMAIL"></a>
                <div class="page-header green-heading">
                  <strong>SECTION C</strong>: EMAIL COMMUNICATIONS
                </div>
				<br>
				
			
			Disclaimer: The information contained in this communication is
				intended solely for use by the individual or entity to whom it is addressed.
				Use and/or distribution of this communication by others is
				prohibited. FraudCheck is neither liable for the proper and complete
				transmission of the information contained in this communication nor
				for any delay in its receipt nor for any special, incidental or
				consequential damages of any nature whatsoever resulting from
				receipt or use of this communication. Opinions, conclusions and
				other information on this message that do not relate to the official
				business of FraudCheck shall be understood as neither given nor
				endorsed by it.
                
                <br><br>
				
                <div class="page-header green-heading">
                  <strong>SECTION D</strong>: GENERAL PROVISIONS
                </div>
				<br>
				
			
			<strong>SERVICES</strong><br> In terms of the services supplied
				in terms of this website, Personal information is submitted to the <strong>Supplier</strong>
				with the knowledge and express consent of both the Subject and the <strong>Client</strong>
				with the view to accessing various data bases to establish various
				trends and risk profiles of the Subject, in accordance with the
				mandate of the <strong>Client</strong>. This information (<strong>Data</strong>)
				is then submitted to the <strong>Client</strong>.
                
                <br><br>

			
				<strong>PAYMENT TERMS</strong><br> The <strong>Client</strong>
				hereby agrees to and is bound by the charges for the selected
				services. The services or <strong>Data</strong> ordered by the <strong>Client</strong>
				shall only be provided by the <strong>Supplier</strong> upon
				positive confirmation that the relevant fee has been received from
				the <strong>Client</strong>. The <strong>Supplier</strong> is
				authorised to deduct the necessary charges from the <strong>Client</strong>'s
				credit card, without the option of reversal. The <strong>Client</strong>
				consents to the <strong>Supplier</strong> proceeding with the
				services for the generation of the <strong>Data</strong> immediately
				upon payment by the <strong>Client</strong>. 
                <br />
                FraudCheck supports credit card payments which you are able to purchase credits once logged on. This allows consumers to make instant online payments directly from their bank accounts via secure logon. Alternatively we allow EFT payments which the credits will be funded once FraudCheck receives proof of payment.
                <br><br>
                
			
			<br>
            <div class="ui-overlaypanel ui-widget ui-widget-content ui-overlay-hidden ui-corner-all ui-shadow ui-helper-clearfix tip" id="paymentMethodDetail"><div class="ui-overlaypanel-content">
				<p>FraudCheck supports credit card, debit card and SID payments.
					SID (Secure Instant Deposit) allows consumers to make instant
			online payments directly from their bank accounts via secure logon.</p></div></div><script id="paymentMethodDetail_s" type="text/javascript">$(function(){PrimeFaces.cw('OverlayPanel','widget_paymentMethodDetail',{id:'paymentMethodDetail',target:'paymentMethod',showEvent:'click',hideEvent:'mouseout',showEffect:'fade',hideEffect:'fade'});});</script><div id="serviceCostsDetail" class="ui-overlaypanel ui-widget ui-widget-content ui-overlay-hidden ui-corner-all ui-shadow ui-helper-clearfix tip"><div class="ui-overlaypanel-content">
				<p>Person Checks range from 1 credit to 6 credits and each
					credit costs R10.00.</p>
				</div></div><script id="serviceCostsDetail_s" type="text/javascript">$(function(){PrimeFaces.cw('OverlayPanel','widget_serviceCostsDetail',{id:'serviceCostsDetail',target:'serviceCosts',showEvent:'click',hideEvent:'mouseout',showEffect:'fade',hideEffect:'fade'});});</script>
			
				<br><br>
			
				<strong>AMENDMENT OF TERMS AND CONDITIONS</strong>
                
                <br><br>
                
                The Terms and Conditions contained therein may, at the sole discretion of the
				<strong>Supplier</strong>, be amended at any time. The <strong>Client</strong>
				is at all times deemed to be familiar with and bound by the latest
				amendments to the Terms and Conditions.<br> These Terms and
				Conditions were last updated on 02 May 2015.
                
                <br><br>
			
				<strong>CONFIDENTIALITY</strong>
                
                <br><br>
                
                All information supplied by the <strong>Client</strong> to the <strong>Supplier</strong> will be
				treated in the utmost confidence, and shall only be utilised in
				terms of the mandate provided for the purposes of generating the <strong>Data</strong>.
				The <strong>Client</strong> and the Subject consent to the passing
				on of confidential information by the <strong>Supplier</strong> to
				reputable Vendors for the purposes of generating the <strong>Data</strong>.
				THE <strong>CLIENT</strong> AND THE SUBJECT FURTHER CONSENT TO THE <strong>SUPPLIER</strong>
				SHARING THE <strong>DATA</strong> WITH THE <strong>SUPPLIER</strong>'S
				ASSOCIATE COMPANIES. The <strong>Supplier</strong> undertakes that
				it complies with Section 68 (Right to confidential treatment) of the
				National Credit Act, 34 of 2005.
			
				<br><br>
			
				<strong>COPYRIGHT</strong><br> The entire contents of this website is subject to Copyright &copy; 2012.
			
				<br><br>
			
				<strong>CONTACT</strong><br> By utilising the services of the <strong>Supplier</strong>,
				you hereby consent to the <strong>Supplier</strong> contacting you
				or your organisation for the purposes of a newsletter, survey or
				marketing purposes. Each communication will present you with an
				opportunity to unsubscribe.
			
				<br><br>
			
				<strong>COOKIES</strong>
                
                <br><br>
                
                Cookies may be utilised by the <strong>Supplier</strong>
				to make the website user-friendly and to enable users to utilise the
				full features of the website. This feature is particularly useful to
				repeat users of this website. Consult your browser in the event that
				you wish to deactivate this feature.
			
				<br><br>
			
				<strong>INFORMATION IN TERMS OF ECTA</strong> (Electronics Communications and Transactions Act)
                
                <br><br>
                
			<table width="100%">
				<tbody><tr>
					<td width="20%">Company name:</td>
					<td width="80%">Placis (Pty) Ltd</td>
				</tr>
				<tr>
					<td>Registration number:</td>
					<td>2013/031750/07</td>
				</tr>
				<tr>
					<td>Physical address:</td>
					<td>164 Katherine Street</td>
				</tr>
				<tr>
					<td></td>
					<td>Pinmill Farm Office Park</td>
				</tr>
				<tr>
					<td></td>
					<td>Strathavon</td>
				</tr>
				<tr>
					<td></td>
					<td>2196</td>
				</tr>
				
				<tr>
					<td>Website address:</td>
					<td>www.fraudcheck.co.za</td>
				</tr>
				<tr>
					<td>E-mail address:</td>
					<td>support@fraudcheck.co.za</td>
				</tr>
			</tbody></table>
			
				<br><br>
				
                <div class="page-header green-heading">
                  <strong>GENERAL</strong>
                </div>
				<br>
				
                
			<ul>
				<li>The law of Republic of South Africa shall be applicable to
					these terms and conditions.</li>
				<li>All notices and legal services shall be served at the <strong>Supplier's</strong>
					physical address and not by email or fax.
				</li>
				<li>In the event that any term herein is declared null and void
					by any competent authority, such a ruling shall not affect the
					validity of the surviving provisions.</li>
			</ul>
			

				<br><br>
				
                <div class="page-header green-heading">
                  <strong>DEFINITIONS</strong>
                </div>
				<br>
				
                
			<table class="defintions">
				<tbody><tr>
					<td>"Client":</td>
					<td>means the person (natural or juristic) who accesses or
						uses this website, its information and/or its services with the
						view to obtaining or utilizing information or Data;</td>
				</tr>
				<tr>
					<td>"Data":</td>
					<td>means the information or consumer profile assessment
						generated by the <strong>Supplier</strong> through the assessment
						of the personal information provided by the Client;
					</td>
				</tr>
				<tr>
					<td>"Subject":</td>
					<td>means the person or entity who is the subject of the
						services of the Supplier, and on whom the profile assessment is
						performed;</td>
				</tr>
				<tr>
					<td>"Supplier":</td>
					<td>means Placis (Pty) Ltd, registration
						number 2009/004370/07;</td>
				</tr>
				<tr>
					<td>"Vendor":</td>
					<td>means any third party company which supplies information
						or data to the Supplier for the purpose of generation of Data, or
						who assists the Supplier in any way whatsoever.</td>
				</tr>
			</tbody></table>
			
          </div>
        </div>
        
    </div>

	<div class="space"></div>
    
    
    <div class="container">
	<p id="back-top" style="display: block;">
	<a href="#top">
	<i class="fa fa-arrow-circle-up fa-5x"></i>
    <br>
	Back to Top
	</a>
	
    </div>
