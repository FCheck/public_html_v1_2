
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center;
          background-size:cover;">
  <div class="container content-header">
    Page not found
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
<div class="container">
	<div class="page-header">
    	<h2 class="green-heading"><strong>Error 404</strong></h2>
        </div>
        We're sorry, unfortunately the page you're looking for cannot be found. If you believe this to be in error, please <a href='contact'>contact us</a>.

 	<div class="space"></div>

</div>
<div class="space"></div>

 <a href="#0" class="cd-top">Top</a>
