
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    Score Card
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
    
    <div class="container">  
    	<div class="row space">
            <div class="col-md-12">
            <h2 class="green-heading">FraudCheck's Unique Scorecard</h2>
            <p><span class="service-question">Are you tired of struggling through hundreds of verification reports, each one presenting information in a different format? </span><br />
            <span class="service-answer">Countless hours are wasted deciphering reports in different formats and styles, costing time and money and dramatically increasing the risk of human error. </span></p>
            <p><span class="service-question">Have you ever wondered if your interpretation is as objective and accurate as you need it to be for the decisions you make? </span><br />
            <span class="service-answer">The impact of human error or bias may expose you or your organisation to significant risks of financial losses or missed opportunities.</span></p>
            <br />
            <h3 class="green-heading">FraudCheck has a solution for YOU!</h3>
            <p>FraudCheck believes that information in isolation has only limited value; true POWER is lies in being able to accurately interpret all the data to find the meaning behind it, so that it can be applied appropriately when making decisions.</p>
            <p>FraudCheck has developed a unique scoring system to evaluate the verification of data it processes. Using advanced algorithms, tuned for the particular needs of your business, verification data is consolidated, analysed, interpreted and translated into a clear fraud screening recommendation report, in real-time.</p>
            <p>The FraudCheck Scorecard presents trustworthy set of recommendations based on your business rules, in a simple, easy to view report, eliminating human subjectivity and wasted time. 
            The FraudCheck Scorecard enables you to make the correct decision on time, every time!</p>


            </div>
        </div>

        <h3 class="green-heading">What does the Recommendation mean?</h3>
    
    	<div class="row space">
          <div class="col-lg-8">
             
             <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-1 space text-center"><img src="images/fraud-prevention-proceed.png"/></div>
                        <div class="col-md-10 space"><p>
                        <strong>Proceed Without Concern - Low Risk (0 and more)</strong>
             <br>
    Our data providers confirmed that most of the details that you provided are valid and therefore presents a low risk. Before proceeding, make sure that you familiarise yourself with any mismatches that may have occurred and take the necessary due diligence to alleviate any concerns.
                        </p></div>
                    </div>
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-1 space text-center"><img src="images/fraud-prevention-caution.png"/></div>
                        <div class="col-md-10 space">
                        <p><strong>Proceed With Caution - Medium Risk (-1 to -49)</strong>
    <br>
    Our data providers reported a considerable number of mismatches between the data you provided and theirs and possibly other more serious issues, which presents a medium risk. FraudCheck recommends that you take the following actions to reduce this risk:</p>
    <ul>
    <li>Perform your own due diligence process by requesting proof of identity, address or contact details to confirm the details that a person provided.</li>
    <li>This process is recommended for all items that received a mismatch in the above report.</li>
    </ul>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-1 space text-center"><img src="images/fraud-prevention-reject.png"/></div>
                        <div class="col-md-10 space">
                        <p><strong>Do Not Proceed - High Risk (-50 and less)</strong>
    <br>
    Our data providers reported an unacceptable number of mismatches between the data you provided and theirs on file and/or a person has received Debt Councelling, Debt Review, has Defaulted on one or more payments or has been issued with one or more Judgements or Notices. Continuing against our fraud screening recommendation of Do not proceed is putting yourself at high risk. You should evaluate all the risks carefully and complete due diligence to reduce this risk before proceeding.
                       </p> </div>
                    </div>
                </div>
            </div>
             
            </div>
            
          <div class="col-lg-4 text-center">
            <a href="images/credit_scorecard.jpg" target="_blank">CLICK TO VIEW SAMPLE REPORT</a><br><br>
			<a href="images/credit_scorecard.jpg" target="_blank"><img src="images/credit_scorecard_thumb.jpg"/></a></div>
        </div>
    </div>
    
    
   <a href="#0" class="cd-top">Top</a>
