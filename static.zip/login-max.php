
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(/images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    Login Fail
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
<div class="container">
	<div class="page-header">
    	<h2 class="green-heading"><strong>Email or Password Incorrect</strong></h2> 
        <p>Please note that you have exceeded the maximum number of unsuccessful login attempts, please reset your password by <a href="reset-password">clicking here</a> or contact support <a href="contact">here</a></p>   
    </div>
 	<div class="space"></div>
    
</div>
<div class="space"></div>
	
 <a href="#0" class="cd-top">Top</a>
