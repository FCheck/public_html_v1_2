
<!-- Header Image
    ================================================== -->
<div class="jumbotron" style="background:url(images/content_header1.jpg) center center; 
          background-size:cover;">
  <div class="container content-header">
    Thought Leadership
    <div class="try"><a href="register"><input type="button" class="btn btn-primary btn-nav" value="TRY NOW" /></a></div>
  </div>
</div> <!-- jumbotron -->


<!-- Content Below
    ================================================== -->
    
    <div class="container">
    
         <div class="page-header">
    	<h2 class="green-heading"><strong><a href='articles/writing-a-captivating-job-description'>Writing a Captivating Job Description</a> </strong></h2>
        <p>If you have ever been online to have a look at job postings, you were browsing the relevant jobs portal searching for a suitable candidate while keeping in mind that probably none of them had any sort of checks to verify their identity...</p>
        <p><input type="button" onclick="document.location.href='articles/writing-a-captivating-job-description'" class="btn btn-success" value="Read More" /></p>
    </div>

         <div class="page-header">
    	<h2 class="green-heading"><strong><a href='articles/toxic-people-to-avoid-hiring'>Toxic people to avoid hiring</a> </strong></h2>
        <p>There are certain personality traits that your company should be cautious about hiring. This can help save your company time and money. We like to think of these personalities as toxic people...</p>
        <p><input type="button" onclick="document.location.href='articles/toxic-people-to-avoid-hiring'" class="btn btn-success" value="Read More" /></p>
    </div>
    
     <div class="page-header">
    	<h2 class="green-heading"><strong><a href='articles/the-big-five'>The Big Five</a> </strong></h2>
        <p>A common method to use is to write an advert of the job description and position you are looking to fill, and posting it online. In the South African market, there are many platforms that offer this service, some requiring a form of identity verification from the candidate...</p>
        <p><input type="button" onclick="document.location.href='articles/the-big-five'" class="btn btn-success" value="Read More" /></p>
    </div>
    
    <div class="page-header">
    	<h2 class="green-heading"><strong><a href='articles/the-costs-of-hiring-the-right-and-wrong-people'>The Costs of Hiring the Right and Wrong People</a> </strong></h2>
        <p>Employing someone to help grow your business is a tricky task. Entrepreneurs or business owners cannot afford to lose money on hiring the wrong people; neither can they lose money by not having enough staff to keep the business running successfully...</p>
        <p><input type="button" onclick="document.location.href='articles/the-costs-of-hiring-the-right-and-wrong-people'" class="btn btn-success" value="Read More" /></p>
    </div>
    
    <div class="page-header">
    	<h2 class="green-heading"><strong><a href='articles/the-employment-evolution'>The Employment Evolution!</a> </strong></h2>
        <p>Over the years, the process of recruiting has radically evolved. Back in the day, there were a couple of dedicated newspapers that would target audiences looking for jobs. That was it! If your dream job didn’t appear for months, there was no hope...</p>
        <p><input type="button" onclick="document.location.href='articles/the-employment-evolution'" class="btn btn-success" value="Read More" /></p>
    </div>
    
    <div class="page-header">
    	<h2 class="green-heading"><strong><a href='articles/wake-up-and-smell-the-roses'>Wake up and smell the roses. (Or the coffee. Whichever you prefer.)</a> </strong></h2>
        <p>It’s pretty difficult to ignore something that smells bad. It consumes you, and in almost an instant you react. Whether you block your nose, gag a little, or fan your face, your reaction to a bad smell tells you instantly that something is not right...</p>
        <p><input type="button" onclick="document.location.href='articles/wake-up-and-smell-the-roses'" class="btn btn-success" value="Read More" /></p>
    </div>
        
    <div class="page-header">
    	<h2 class="green-heading"><strong><a href='articles/one-word-google'>One word: Google.</a> </strong></h2>
        <p>These days, we have access to endless amounts of information; you could potentially find good background information on anyone or at the very least, verify identity. The information found online does contain information that is useless (think “ten steps to learning Gangnam Style”), while some information can be pretty useful...</p>
        <p><input type="button" onclick="document.location.href='articles/one-word-google'" class="btn btn-success" value="Read More" /></p>   
    </div>
    
    <div class="page-header">
    	<h2 class="green-heading"><strong><a href='articles/dont-judge-a-book-by-its-cover'>Don&acute;t Judge a Book by its Cover</a> </strong></h2>
        <p>There’s a reason this is the most clichéd saying in the world (we Googled it, and yes, it has been voted the biggest cliché ever). Looks can be deceiving, how could one truly verify an identity? We’ve been taught that confidence is a good thing, and while this is true, often confidence can turn into cockiness or even a cover up for someone’s true personality...</p>
        <p><input type="button" onclick="document.location.href='articles/dont-judge-a-book-by-its-cover'" class="btn btn-success" value="Read More" /></p>   
    </div>
    
    <div class="page-header">
    	<h2 class="green-heading"><strong><a href='articles/believe-it-or-not-a-cv-can-lie'>Believe it or not: A CV can lie</a> </strong></h2>
        <p>Why do companies ask for a CV before meeting with someone? So that they don’t waste time interviewing people who do not have the necessary skill set, experience or expertise. The idea of a CV is wonderful in theory, verifying identity and finding about the applicant at the same time. But often, the reality of receiving CV’s turns out to be far less helpful than one would like it to be. This is because a CV can lie...</p>
		<p><input type="button" onclick="document.location.href='articles/believe-it-or-not-a-cv-can-lie'" class="btn btn-success" value="Read More" /></p>   
    </div>
    <div class="page-header">
    	<h2 class="green-heading"><strong><a href='articles/sweat-baby-sweat-body-language-to-look-out-for'>Sweat Baby Sweat - Body language and the worrying signs you should look out for</a></strong></h2>
        <p>Body language is a real thing. Even though it’s the middle of winter and everyone else in this interview is shivering, your candidate seems to be quite worked up. Deceiving someone is hard work. They say it takes a lot more effort to frown than to smile...</p>
		<p><input type="button" onclick="document.location.href='articles/sweat-baby-sweat-body-language-to-look-out-for'" class="btn btn-success" value="Read More" /></p>   
    </div>
    <div class="page-header">
    	<h2 class="green-heading"><strong><a href='articles/have-you-ever-been-duped-swindled-conned'>Have you ever been duped, swindled or conned?</a></strong></h2>
        <p>Have you ever been duped, swindled or conned? It’s not a great feeling. The word ‘con’ as in conman or confidence trickster comes from the idea that this person sets out to defraud an individual or company by first gaining his victim’s confidence or trust. One Victor Lustig actually ‘sold’ the Eiffel Tower for scrap metal. Andre Poisson, duped by forged government credentials, the limousine ride to the site, and the tale that the city...</p>
		<p><input type="button" onclick="document.location.href='articles/have-you-ever-been-duped-swindled-conned'" class="btn btn-success" value="Read More" /></p>   
    </div>
    	<div class="page-header">
    	<h2 class="green-heading"><strong><a href='articles/pre-employment-screening-vital-to-employment'>Pre Employment Screening is vital to the Employment Process</a></strong></h2>
        <p>South African employers now have to change their modis operandi when making employment and hiring decisions. 
Recently we have seen many senior high profile leaders in both corporate and government entities being caught out for lying on their CVs and job applications.  Jeff Miller the acting CEO of Fraud Check estimates...</p>
		<p><input type="button" onclick="document.location.href='articles/pre-employment-screening-vital-to-employment'" class="btn btn-success" value="Read More" /></p>   
    </div>
    
    <div class="page-header">
    	<h2 class="green-heading"><strong><a href='articles/drivers-license-for-sale'>Drivers Licenses for Sale</a></strong></h2>
        <p>Where did you get your drivers licence is an extremely common question asked of South African drivers. Yes, believe it or not, fraudulent drivers licenses are a common phenomenon in our country. When it comes to employing drivers, companies need to be extra vigilant...</p>
		<p><input type="button" onclick="document.location.href='articles/drivers-license-for-sale'" class="btn btn-success" value="Read More" /></p>   
    </div>
    
    <div class="page-header">
    	<h2 class="green-heading"><strong><a href='articles/white-collar-crime-south-africa'>White Collar Crime in South Africa has Gone Wild</a></strong></h2>
        <p>White collar crime in South Africa has gone wild. Jeff miller acting CEO of Fraud check says it is vital for companies to conduct pre-employment screening of applicants before appointing them. Has the applicant got a valid ID number...</p>
		<p><input type="button" onclick="document.location.href='articles/white-collar-crime-south-africa'" class="btn btn-success" value="Read More" /></p>   
    </div>
    
 	<div class="space"></div>
    </div>
    
   <a href="#0" class="cd-top">Top</a>
